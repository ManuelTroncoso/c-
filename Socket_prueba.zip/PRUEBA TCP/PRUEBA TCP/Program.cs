﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.IO;

namespace PRUEBA_TCP
{
    class Program
    {
        static void Main(string[] args)
        {
            TcpListener servidor = new TcpListener(9999);
            servidor.Start();

            while (true)
            {
                TcpClient cliente = servidor.AcceptTcpClient();
                NetworkStream ns = cliente.GetStream();
                StreamWriter sw = new StreamWriter(ns);
                StreamReader sr = new StreamReader(ns);
                DateTime dia = DateTime.Now;
                string texto = "inicio";
                while (texto != "")
                {
                    Console.Write("Tú: ");
                    texto = Console.ReadLine();

                    sw.WriteLine("Manu: " + texto + " (" + dia.ToString() + ")");
                    
                    sw.Flush();
                    Console.WriteLine(sr.ReadLine());

                   
                }
                sw.Close();
                sr.Close();
                ns.Close();
                cliente.Close();
            }
            
        }
    }
}
