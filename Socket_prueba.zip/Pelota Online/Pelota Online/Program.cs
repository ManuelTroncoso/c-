﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Net.Sockets;
using System.IO;

namespace Pelota_Online
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.CursorVisible = false;
            int x, y;
            Random x2 = new Random();
            x = x2.Next(Console.WindowWidth);
            Random y2 = new Random();
            y = y2.Next(Console.WindowHeight);
            int velx = 1, vely = 1;
            Console.SetCursorPosition(x, y);
            Console.WriteLine("O");
           

            TcpListener servidor = new TcpListener(9999);
            servidor.Start();

            while (true)
            {
                TcpClient cliente = servidor.AcceptTcpClient();
                NetworkStream ns = cliente.GetStream();
                StreamWriter sw = new StreamWriter(ns);
                StreamReader sr = new StreamReader(ns);
                DateTime dia = DateTime.Now;

                while (true)
                {
                    while (true)
                    {
                        Thread.Sleep(20);
                        Console.SetCursorPosition(x, y);
                        Console.WriteLine(" ");

                        x = x + velx;
                        y = y + vely;

                        if (x == 0)
                        {
                            velx = -velx;
                        }
                        else
                        {
                            if (x == Console.WindowWidth)
                            {
                                sw.WriteLine(y);
                                sw.WriteLine(vely);
                                sw.Flush();
                                break;
                            }
                        }
                        if (y == 0 || y == Console.WindowHeight - 2)
                        {
                            vely = -vely;
                        }
                        if (y < 30 || x < 120)
                        {
                            Console.SetCursorPosition(x, y);
                            Console.WriteLine("O");
                        }
                    }

                    y = int.Parse(sr.ReadLine());
                    vely = int.Parse(sr.ReadLine());
                    x = 119;
                    velx = -1;

                    
                    
                }

                sw.Close();
                sr.Close();
                ns.Close();
                cliente.Close();
            }
           
        }
    }
}
