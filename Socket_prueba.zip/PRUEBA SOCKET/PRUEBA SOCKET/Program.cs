﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.IO;
using System.Net;
using System.Threading;

namespace PRUEBA_SOCKET
{
    class Program
    {
        static void Main(string[] args)
        {
            //var permission = new SocketPermission(NetworkAccess.Accept,
            //       TransportType.Tcp, "", SocketPermission.AllPorts);

            Socket s = new Socket(SocketType.Stream, ProtocolType.Tcp);

            s.Bind(new IPEndPoint(new IPAddress(new byte[] { 172, 30, 250, 6 }), 1000));
            s.Listen(1000);
            Console.WriteLine("Waiting for a connection...");
            // Program is suspended while waiting for an incoming connection.  
            Socket handler = s.Accept();

            // An incoming connection needs to be processed.  
            NetworkStream ns = new NetworkStream(handler);

            StreamWriter sw = new StreamWriter(ns);
            Console.WriteLine("Hola que tal");
            sw.WriteLine("Hola que tal");
            sw.Close();

            NetworkStream ns2 = new NetworkStream(handler);
            StreamReader sr = new StreamReader(ns2);
            Console.WriteLine(sr.ReadLine());
            sr.Close();

            ns2.Close();
            ns.Close();
            handler.Close();




            Console.ReadKey();
        }


    }
}
