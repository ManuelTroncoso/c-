﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Struct_Banco
{
    class Program
    {
        struct cuenta_corriente
        {
            public string numero_cc;
            public string cliente;
            public decimal saldo;
        }
        /// <summary>
        /// Añade una cuenta a la lista 
        /// </summary>
        /// <param name="lista">nombre de la lista</param>        static void NuevaCuentaBanco(List<cuenta_corriente> lista)
        {
            Console.WriteLine("Dime el número de cuenta:");
            string numero = Console.ReadLine();
            for (int i = 0; i < lista.Count; i++)
            {
                if (lista[i].numero_cc == numero)
                {
                    Console.WriteLine("Número de cuenta ya existente");
                    Console.WriteLine("Introduzca otro número de cuenta:");
                    numero = Console.ReadLine();
                    i = 0;
                }
            }
            Console.WriteLine("Dime el nombre del propietario:");
            string nombre = Console.ReadLine();
            Console.WriteLine("Dime el saldo:");
            decimal saldo = decimal.Parse(Console.ReadLine());

            cuenta_corriente p1;

            p1.numero_cc = numero;
            p1.cliente = nombre;
            p1.saldo = saldo;

            lista.Add(p1);
        }
        /// <summary>
        /// Elimina una cuenta de la lista
        /// </summary>
        /// <param name="lista">nombre de la lista</param>
        /// <param name="numerocuenta">numero de la cuenta que vamos a eliminar</param>
        static void EliminarCuentaBanco(List<cuenta_corriente> lista, string numerocuenta)
        {
            int i;
            for (i = 0; i < lista.Count; i++)
            {
                if (numerocuenta == lista[i].numero_cc)
                {
                    lista.RemoveAt(i);
                    break;
                }
            }
        }
        /// <summary>
        /// Actualiza el saldo de una cuenta
        /// </summary>
        /// <param name="lista">nombre de la lista</param>
        /// <param name="numerocuenta">numero de la cuenta</param>
        static void ActualizarSaldoBanco(List<cuenta_corriente> lista, string numerocuenta)
        {
            Console.WriteLine("Añade la cantidad de dinero:");
            decimal dinero = decimal.Parse(Console.ReadLine());

            cuenta_corriente p;

            for (int i = 0; i < lista.Count; i++)
            {
                if (lista[i].numero_cc == numerocuenta)
                {
                    p = lista[i];
                    p.saldo = p.saldo + dinero;
                    lista[i] = p;
                }
            }
        }
        /// <summary>
        /// Imprime por pantalla las cuentas de la lista
        /// </summary>
        /// <param name="lista">nombre de la lista</param>
        static void ImprimirCuentasBanco(List<cuenta_corriente> lista)
        {
            int i;

            for (i = 0; i < lista.Count; i++)
            {
                Console.WriteLine("Cuenta " + (i + 1) + " :");
                Console.WriteLine("Número de Cuenta: " + lista[i].numero_cc);
                Console.WriteLine("Nombre Cliente: " + lista[i].cliente);
                Console.WriteLine("saldo: " + lista[i].saldo);
                Console.WriteLine("==================");
            }
        }
        /// <summary>
        /// Guarda la lista en un fichero binario
        /// </summary>
        /// <param name="lista">nombre de la lista</param>
        /// <param name="nombrefichero">nombre del fichero</param>
        static void GuardarFicheroBanco(List<cuenta_corriente> lista, string nombrefichero)
        {
            FileStream fs = new FileStream(nombrefichero, FileMode.Create);
            BinaryWriter bw = new BinaryWriter(fs);

            bw.Write(lista.Count);
            int i;

            for (i = 0; i < lista.Count; i++)
            {
                bw.Write(lista[i].numero_cc);
                bw.Write(lista[i].cliente);
                bw.Write(lista[i].saldo);
            }

            fs.Close();
            bw.Close();
        }
        /// <summary>
        /// Lee las cuentas de un fichero binario y las guarda en una lista.
        /// </summary>
        /// <param name="l">nombre de la lista</param>
        /// <param name="nombrefichero"> nombre del fichero</param>
        static void LeerFicheroBanco(List<cuenta_corriente> l, string nombrefichero)
        {
            int i;
            l.Clear();
            cuenta_corriente p1;

            FileStream fs = new FileStream(nombrefichero, FileMode.Open);
            BinaryReader br = new BinaryReader(fs);

            int numero = br.ReadInt32();

            for (i = 0; i < numero; i++)
            {
                p1.numero_cc = br.ReadString();
                p1.cliente = br.ReadString();
                p1.saldo = br.ReadDecimal();
                l.Add(p1);
            }

            fs.Close();
            br.Close();
        }
        /// <summary>
        /// Guarda los datos de la lista en un fichero texto
        /// </summary>
        /// <param name="lista">nombre de la lista</param>
        /// <param name="nombrefichero">nombre del fichero</param>
        static void GuardarFicheroBancoTXT(List<cuenta_corriente> lista, string nombrefichero)
        {
            StreamWriter sw = new StreamWriter(nombrefichero);

            sw.WriteLine(lista.Count);
            int i;

            for (i = 0; i < lista.Count; i++)
            {
                sw.WriteLine(lista[i].numero_cc);
                sw.WriteLine(lista[i].cliente);
                sw.WriteLine(lista[i].saldo);
            }
            sw.Close();
        }
        /// <summary>
        /// Lee los datos de un fichero texto y los guarda en una lista
        /// </summary>
        /// <param name="lista">nombre lista</param>
        /// <param name="nombrefichero">nombre del fichero</param>
        static void LeerFicheroBancoTXT(List<cuenta_corriente> l, string nombrefichero)
        {
            int i;
            l.Clear();
            cuenta_corriente p1;

            StreamReader sr = new StreamReader(nombrefichero);

            int numero = sr.Read();

            for (i = 0; i < numero; i++)
            {
                p1.numero_cc = sr.ReadLine();
                p1.cliente = sr.ReadLine();
                p1.saldo = sr.Read();
                l.Add(p1);
            }

            sr.Close();
        }
        /// <summary>
        /// Guarda los datos de la lista en un fichero CSV
        /// </summary>
        /// <param name="l">nombre de la lista</param>
        /// <param name="nombrefichero">nombre del fichero</param>
        static void GuardarFicheroBancoCSV(List<cuenta_corriente> l, string nombrefichero)
        {
            int i;

            StreamWriter sw = new StreamWriter(nombrefichero);

            for (i = 0; i < l.Count; i++)
            {
                sw.Write(l[i].numero_cc + ";");
                sw.Write(l[i].cliente + ";");
                sw.WriteLine(l[i].saldo + ";");
            }

            sw.Close();
        }
        /// <summary>
        /// Escribe los datos de un fichero CSV en una lista de struct
        /// </summary>
        /// <param name="l">nombre de la lista</param>
        /// <param name="nombrefichero">nombre del fichero</param>
        static void LeerFicheroBancoCSV(List<cuenta_corriente> l, string nombrefichero)
        {
            l.Clear();
            int i;
            StreamReader sr = new StreamReader(nombrefichero);
            string[] letrasfichero = { "" };
            string linea;
            cuenta_corriente p;
            while (!sr.EndOfStream)
            {
                linea = sr.ReadLine();
                letrasfichero = linea.Split(';');

            }
            for (i = 0; i < letrasfichero.Length; i++)
            {
                p.numero_cc = letrasfichero[i];
                p.cliente = letrasfichero[i];
                p.saldo = decimal.Parse(letrasfichero[i]);
            }
            sr.Close();
        }
        static void Main(string[] args)
        {
            List<cuenta_corriente> banco = new List<cuenta_corriente>();            int opcion = -1;

            while (opcion != 0)
            {
                Console.Clear();
                Console.WriteLine("MENU");
                Console.WriteLine("====");
                Console.WriteLine();
                Console.WriteLine("1- NuevaCuentaBanco");
                Console.WriteLine("2- EliminarCuentaBanco");
                Console.WriteLine("3- ActualizarSaldoBanco");
                Console.WriteLine("4- ImprimirCuentasBanco");
                Console.WriteLine("5- GuardarFicheroBanco");
                Console.WriteLine("6- LeerFicheroBanco");
                Console.WriteLine("7- GuardarFicheroBancoTXT");
                Console.WriteLine("8- LeerFicheroBancoTXT");
                Console.WriteLine("9- GuardarFicheroBancoCSV");
                Console.WriteLine("10- LeerFicheroBancoCSV");
                Console.WriteLine("==========================");
                Console.WriteLine();
                Console.WriteLine("Salir = 0");
                opcion = int.Parse(Console.ReadLine());
                switch (opcion)
                {
                    case 1: Console.Clear(); NuevaCuentaBanco(banco); Console.ReadKey(); break;
                    case 2: Console.Clear(); Console.WriteLine("Número de la cuenta que quieres eliminar"); string numerocuenta = Console.ReadLine(); EliminarCuentaBanco(banco, numerocuenta); Console.ReadKey(); break;
                    case 3: Console.Clear(); Console.WriteLine("Número de la cuenta:"); string numerocuenta2 = Console.ReadLine(); ActualizarSaldoBanco(banco, numerocuenta2); Console.ReadKey(); break;
                    case 4: Console.Clear(); ImprimirCuentasBanco(banco); Console.ReadKey(); break;
                    case 5: Console.Clear(); GuardarFicheroBanco(banco, "Banco.cc"); Console.WriteLine("Fichero creado !!!!"); Console.ReadKey(); break;
                    case 6: Console.Clear(); LeerFicheroBanco(banco, "Banco.cc"); Console.WriteLine("Guardado en la lista"); Console.ReadKey(); break;
                    case 7: Console.Clear(); GuardarFicheroBancoTXT(banco, "Banco.txt"); Console.WriteLine("Fichero Creado !!!!"); Console.ReadKey(); break;
                    case 8: Console.Clear(); LeerFicheroBancoTXT(banco, "Banco.txt"); Console.WriteLine("Guardado en la lista"); Console.ReadKey(); break;
                    case 9: Console.Clear(); GuardarFicheroBancoCSV(banco, "BancoCSV.txt"); Console.WriteLine("Fichero Creado!!!!!"); Console.ReadKey(); break;
                    case 10: Console.Clear(); LeerFicheroBancoCSV(banco, "BancoCSV.txt"); Console.WriteLine("Guardado en la lista"); Console.ReadKey(); break;
                }
            }
        }
    }
}
