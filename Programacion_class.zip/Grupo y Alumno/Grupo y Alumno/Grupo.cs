﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grupo_y_Alumno
{
    class Grupo
    {
        //Atributo
        private List<Alumno> listaAlumnos;

        //Constructor
        public Grupo()
        {
            listaAlumnos = new List<Alumno>();
        }

        //Métodos
        public void InsertaAlumnosLista(Alumno a)
        {
            listaAlumnos.Add(a);
        }

        public void InsertaAlumnoLista (string nombre, int edad, decimal calificacion)
        {
            Alumno a = new Alumno(nombre, edad, calificacion);
            listaAlumnos.Add(a);
        }

        public string Imprime()
        {
            string datos = "";
            
            for(int i = 0; i< listaAlumnos.Count; i++)
            {
                datos = datos + listaAlumnos[i].Imprime() + "\n";
                
            }
            return datos;
        }

        public void EscribeFicheroAlumnos(string nombre)
        {
            FileStream fs = new FileStream(nombre, FileMode.Create);
            BinaryWriter bw = new BinaryWriter(fs);
            int i = 0;
            bw.Write(listaAlumnos.Count);
            for (i = 0; i < listaAlumnos.Count; i++)
            {
                bw.Write(listaAlumnos[i].Nombre);
                bw.Write(listaAlumnos[i].Edad);
                bw.Write(listaAlumnos[i].Calificacion);
            }

            bw.Close();
            fs.Close();
        }
        public void LeeFicheroAlumnos(string nombre)
        {
            int i;
            listaAlumnos.Clear();
            FileStream fs = new FileStream(nombre, FileMode.Open);
            BinaryReader br = new BinaryReader(fs);
            int numero = br.ReadInt32();
            for (i = 0; i < numero; i++)
            {
                Alumno a = new Alumno(br.ReadString(), br.ReadInt32(), br.ReadDecimal());
                listaAlumnos.Add(a);
            }
            
            br.Close();
            fs.Close();
        }
        public void EscribeFicheroAlumnosTXT(string nombre)
        {
            StreamWriter sw = new StreamWriter(nombre);

            int i = 0;
            sw.WriteLine(listaAlumnos.Count);
            for (i = 0; i < listaAlumnos.Count; i++)
            {

                sw.WriteLine(listaAlumnos[i].Nombre);

                sw.WriteLine(listaAlumnos[i].Edad);

                sw.WriteLine(listaAlumnos[i].Calificacion);

            }
            sw.Close();
        }
        public void LeeFicheroAlumnoTXT(string nombre)
        {
            int i;
            listaAlumnos.Clear();
            StreamReader st = new StreamReader(nombre);

            int numero = int.Parse(st.ReadLine());
            for (i = 0; i < numero; i++)
            {

                 Alumno a = new Alumno(st.ReadLine(), int.Parse(st.ReadLine()), decimal.Parse(st.ReadLine()));
                listaAlumnos.Add(a);
            }
            st.Close();

        }
        public void EscribeFicheroAlumnosCSV(string nombre)
        {
            int i;
            StreamWriter sw = new StreamWriter(nombre);

            for (i = 0; i < listaAlumnos.Count; i++)
            {
                sw.Write(listaAlumnos[i].Nombre + ";");

                sw.Write(listaAlumnos[i].Edad + ";");

                sw.WriteLine(listaAlumnos[i].Calificacion);
            }
            sw.Close();
        }
        public void LeeFicheroAlumnoCSV(string nombre)
        {
            int i;
            listaAlumnos.Clear();
            StreamReader st = new StreamReader(nombre);
            string[] datos = { "" };
            string linea;
            while (!st.EndOfStream)
            {
                linea = st.ReadLine();
                datos = linea.Split(';');

            }
            for (i = 0; i < datos.Length; i++)
            {
                Alumno a = new Alumno(st.ReadLine(), int.Parse(st.ReadLine()), decimal.Parse(st.ReadLine()));
                listaAlumnos.Add(a);
            }
            st.Close();

        }
    }
}
