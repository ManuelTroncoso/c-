﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grupo_y_Alumno
{
    class Alumno
    {
        //Atributo
        private string nombre;
        private int edad;
        private decimal calificacion;

        //Propiedades

        public string Nombre
        {
            get
            {
                return this.nombre;
            }

            set
            {
                if (value == "")
                {
                    throw new Exception("El nombre no es correcto");
                }
                else
                {
                    this.nombre = value;
                }
            }
        }


        public int Edad
        {
            set
            {
                if (edad > 100 || edad < 17)
                {
                    throw new Exception("Edad no validad");
                }
                else
                {
                    this.edad = value;
                }
            }
            get
            {
                return this.edad;
            }
        }
        public decimal Calificacion
        {
            set
            {
                if (calificacion > 10 || calificacion < 0)
                {

                    throw new Exception("Calificación no válida");
                }
                else
                {
                    this.calificacion = value;
                }
            }
            get
            {
                return this.calificacion;
            }
        }

        //Constructores

        public Alumno(string nombre, int edad, decimal calificacion)
        {
            this.Nombre = nombre;
            this.Edad = edad;
            this.Calificacion = calificacion;
        }

        //Método
        public string Imprime()
        {
            string datos;
            datos = "nombre:" + nombre + " | " + "edad: " + edad.ToString() + " | " + "calificacion:" + calificacion.ToString();
            return datos;
            
        }
    }
}
