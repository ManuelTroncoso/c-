﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carta_y_Baraja
{
    class Baraja
    {
        //Atributos
        private List<Carta> listaCarta;

        //Contructores
        public Baraja()
        {
            listaCarta = new List<Carta>();
        }

        public Baraja(int tipobaraja) : this()
        {
            //listaCarta = new List<Carta>();
            int i, j;
            if(tipobaraja == 1||tipobaraja==2)
            {
                if (tipobaraja == 1)
                {
                    for (i = 1; i <= 40; i++)
                    {
                        Carta c = new Carta(i);
                        listaCarta.Add(c);
                    }
                }
                else
                {
                    if (tipobaraja == 2)
                    {
                        for (i = 1, j = 1; j <= 80; j++, i++)
                        {
                            Carta c = new Carta(i);
                            listaCarta.Add(c);
                            if (i == 40)
                            {
                                i = 1;
                            }
                        }
                    }
                }
            }
            else
            {
                throw new Exception("Valor no valido");
            }
        }
        public Baraja (int tipobaraja, bool barajar) : this(tipobaraja)
        {
            if (barajar == true)
            {
                Barajar();
            }
        }

        //Método
        public void Barajar()
        {
            List<Carta> cartabarajadas = new List<Carta>();
            
            Random r = new Random();
            while (listaCarta.Count > 0)
            {
                
                int aleatorio = r.Next(0 ,listaCarta.Count);
                cartabarajadas.Add(listaCarta[aleatorio]);
                listaCarta.RemoveAt(aleatorio);
                
            }
            listaCarta.AddRange(cartabarajadas);
        }
        public void Cortar(int posicion)
        {
            int i;
            List<Carta> cartascortadas = new List<Carta>();
            for (i = posicion;i<listaCarta.Count; i++ )
            {
                cartascortadas.Add(listaCarta[i]);
                listaCarta.RemoveAt(i);

            }
            listaCarta.AddRange(cartascortadas);

        }
        public Carta Robar()
        {
            if (this.listaCarta.Count > 0)
            {
                Carta c = listaCarta[0];
                listaCarta.RemoveAt(0);
                return c;
            }
            else
            {
                throw new Exception("Valor no valido");
            }
        }
        public void InsertaCartaFinal (int id_carta)
        {
            Carta c = new Carta (id_carta);
            listaCarta.Add(c);
        } 
        public void InsertaCartaInicio (int id_carta)
        {
            Carta c = new Carta(id_carta);
            listaCarta.Insert(0, c);
        }
        public void InsertaCartaFinalOBJ(Carta c)
        {
            listaCarta.Add(c);
        }
        public void InsertaCartaInicioOBJ(Carta c)
        {
           listaCarta.Insert(0, c);
        }


        //Propiedades
        public int NumeroCarta
        {
            get
            {
                return listaCarta.Count;
            }
        }
        public bool Vacia
        {
            get
            {
                if(listaCarta.Count == 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }

                //return (listaCarta.Count == 0);
            }
        }



    }
}
