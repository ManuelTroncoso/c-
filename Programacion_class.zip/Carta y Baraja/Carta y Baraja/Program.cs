﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carta_y_Baraja
{
    class Program
    {
        static void Main(string[] args)
        {
            int i;
            i = 0;
            Baraja b = new Baraja(1, true);
            decimal puntos = 0;
            while(i == 1 || puntos < 7.5m)
            {


                Carta c = b.Robar();
                decimal valor = c.Valor7ymedia;
                puntos = puntos + valor;
                Console.WriteLine("Llevas= " + puntos);
                Console.WriteLine("¿Deseas continuar sacando cartas? Si = 0/ No = 1");
                
              
                i = int.Parse(Console.ReadLine());
        
            }

            if (puntos > 7.5m)
            {
                Console.WriteLine("Has superado el limite");
            }
            Console.ReadKey();

        }
    }
}
