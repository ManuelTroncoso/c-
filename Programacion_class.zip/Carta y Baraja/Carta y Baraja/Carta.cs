﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carta_y_Baraja
{
    class Carta
    {
        //Atributos
        //Si ponemos public se podría modificar
        private int numero;
        private int palo;

        //Constructores
        //Es para crear una carta nueva y comprobarla si lo valores son correctos
        /// <summary>
        /// Nos crea una carta con el valo que le hemos pasa
        /// </summary>
        /// <param name="numero">Valor máximo 10, y mínimo 1, del 1 al 7 son los numero normales de la carta
        /// y 8, 9 y 10 son Sota, Caballo y Rey</param>
        /// <param name="palo">ORO, COPA, ESPADA, BASTO</param>
        public Carta(int numero, int palo)
        {
            if (numero > 10 || numero < 1 && palo > 3 || palo < 0)
            {
                throw new Exception("Valor no valido");
            }
            else
            {
                this.numero = numero;
                this.palo = palo;
            }

        }
        public Carta(int id)
        {
            if (id <= 40 && id > 0)
            {
                if (id <= 10)
                {
                    palo = 0; //ORO
                    numero = id;
                }
                else
                {
                    if (id <= 20)
                    {
                        palo = 1; //COPA
                        numero = id - 10;
                    }
                    else
                    {
                        if (id <= 30)
                        {
                            palo = 2; //ESPADA
                            numero = id - 20;
                        }
                        else
                        {
                            palo = 3; //BASTO
                            numero = id - 30;
                        }
                    }
                } 
               
            }
            else
            {
                throw new Exception("Valor no valido");
            }
        }

        //Propiedades
        //Se parecen a una función pero sin parametro
        //Es para que el usuario pueda usar los atributos sin modificarlo
        public int Numero
        {
            get
            {
                return this.numero;
            }
        }
        public int Palo
        {
            get
            {
                return this.palo;
            }
        }
        /// <summary>
        /// Nos devuelve el valor de numero en texto.
        /// </summary>
        public string NombreNumero
        {
            get
            {
                string cadena;

                switch (this.numero)
                {
                    case 1: cadena = "as"; break;
                    case 2: cadena = "dos"; break;
                    case 3: cadena = "tres"; break;
                    case 4: cadena = "cuatro"; break;
                    case 5: cadena = "cinco"; break;
                    case 6: cadena = "seis"; break;
                    case 7: cadena = "siete"; break;
                    case 8: cadena = "sota"; break;
                    case 9: cadena = "caballo"; break;
                    case 10: cadena = "rey"; break;
                    default: throw new Exception("Valor no valido");

                }

                return cadena;
            }
        }
        public string NombrePalo
        {
            get
            {
                //Se puede hacer con una cadena.
                string cadena;
                switch (this.palo)
                {
                    case 0: cadena = "oro"; break;
                    case 1: cadena = "copa"; break;
                    case 2: cadena = "espada"; break;
                    case 3: cadena = "basto"; break;
                    default: throw new Exception("Valor no valido");
                }
                return cadena;
            }
        }
        public string NombreCarta
        {
            get
            {
                return NombreNumero + " de " + NombrePalo;
            }
        }
        public int ValorTute
        {
            get
            {
                int cadena;
                switch (this.numero)
                {
                    case 1: cadena = 11; break;
                    case 10: cadena = 2; break;
                    case 11: cadena = 3; break;
                    case 12: cadena = 4; break;
                    default: cadena = 0;break;
                }
                return cadena;
            }
        }
        public int ValorMus
        {
            get
            {
                int cadena;
                switch (this.numero)
                {
                    case 1: cadena = 1; break;
                    case 2: cadena = 1; break;
                    case 3: cadena = 3; break;
                    case 4: cadena = 4; break;
                    case 5: cadena = 5; break;
                    case 6: cadena = 5; break;
                    case 7: cadena = 7; break;
                    case 8: cadena = 8; break;
                    case 9: cadena = 9; break;
                    case 10: cadena = 10; break;
                    case 11: cadena = 10; break;
                    case 12: cadena = 10; break;

                    default: throw new Exception("Valor no valido");
                }
                return cadena;
            }
        }
        public decimal Valor7ymedia
        {

            get
            {
                decimal cadena;
                switch (this.numero)
                {
                    case 1: cadena = 1; break;
                    case 2: cadena = 1; break;
                    case 3: cadena = 3; break;
                    case 4: cadena = 4; break;
                    case 5: cadena = 5; break;
                    case 6: cadena = 5; break;
                    case 7: cadena = 7; break;
                    case 8: cadena = 0.5m; break;
                    case 9: cadena = 0.5m; break;
                    case 10: cadena = 0.5m; break;

                    default: throw new Exception("Valor no valido");
                }
                
                return cadena;
            }
            
        }


        public override string ToString() //Para que me lo escriba en pantalla
        {
            return NombreCarta;
        }
    }
}
