﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fracciones
{
    class Fraccion
    {
        //Artributos
        private int numerador;
        private int denominador;

        //Constructores
        public Fraccion(int numerador, int denominador)
        {
            if (denominador == 0)
            {
                throw new Exception("Denominador debe ser mayor que '0'");
            } else
            {
                this.numerador = numerador;
                this.denominador = denominador;
            }        
        }
        public Fraccion (int numero)
        {
            numerador = numero;
            denominador = 1;
        }
        public Fraccion (double numero)
        {
            //Ir restandole uno al numero y si este da 0 es por que el valor no es decimal, 
            // de lo contrario el numero es decimal;
        }
    }
}
