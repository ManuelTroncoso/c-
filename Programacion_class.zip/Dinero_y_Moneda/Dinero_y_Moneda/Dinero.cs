﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;

namespace Dinero_y_Moneda
{


    class Dinero
    {
        //Atributos Estáticos
        public static List<Moneda> listaMoneda;

        //Constructores Estáticos
        static Dinero()
        {
            listaMoneda = new List<Moneda>();

            Moneda m = new Moneda(TipoMoneda.Euro, 2, "€", 1, "EUR");
            listaMoneda.Add(m);

            Moneda m1 = new Moneda(TipoMoneda.Dolar, 2, "$", 0.807871904M, "USD");
            listaMoneda.Add(m1);

            Moneda m2 = new Moneda(TipoMoneda.Peso, 2, "$(Mx)", 0.0442390655M, "MXN");
            listaMoneda.Add(m2);

            Moneda m3 = new Moneda(TipoMoneda.British_Pound, 2, "£", 5M, "GBP");
            listaMoneda.Add(m3);
        }

        //Métodos Estáticos
        public static void ActualizaCambio(TipoMoneda tipo, decimal ValorActualizado)
        {
            int i;
            for (i = 0; i < listaMoneda.Count; i++)
            {
                if (listaMoneda[i].Tmoneda == tipo)
                {
                    listaMoneda[i].CambioEuro = ValorActualizado;
                }
            }
        }

        //Atributos 
        /// <summary>
        /// Cantidad = cantidad de dinero
        /// moneda es el tipo de moneda que tengo
        /// </summary>
        private decimal cantidad;
        private TipoMoneda moneda;

        //Constructores
        public Dinero(decimal cantidad, TipoMoneda moneda)
        {
            this.cantidad = cantidad;
            this.moneda = moneda;
        }
        public Dinero(int cantidad, TipoMoneda moneda)
        {
            this.cantidad = (int)cantidad;
            this.moneda = moneda;
        }
        public Dinero(double cantidad, TipoMoneda moneda)
        {
            this.cantidad = (decimal)cantidad;
            this.moneda = moneda;
        }

        //Propiedades
        public decimal Cantidad
        {
            get
            {
                return cantidad;
            }
            set
            {
                cantidad = value;
            }
        }
        public TipoMoneda TipodeMoneda
        {
            get
            {
                return moneda;
            }
            set
            {
                moneda = value;
            }
        }

        //Método
        public int PosicionMoneda(TipoMoneda moneda)
        {
            int i;
            for (i = 0; i < listaMoneda.Count; i++)
            {
                if(listaMoneda[i].Tmoneda == moneda)
                {
                    return i;
                }
               
               

            }
            return -1;
        }
        public string ToString()
        { 
            string moneda_pantalla = "";
            int a = PosicionMoneda(this.moneda);
            return moneda_pantalla = Math.Round(cantidad, listaMoneda[a].Decimales) + listaMoneda[a].Simbolo;
        }

        public decimal ValorEn(TipoMoneda tipo)
        {
            int i;
            decimal valor = 0;
            valor = cantidad / listaMoneda[PosicionMoneda(moneda)].CambioEuro;
            valor = valor * listaMoneda[PosicionMoneda(tipo)].CambioEuro;
            return valor;

        }

        public Dinero ConvierteEn(TipoMoneda tipo)
        {
            int i, a = 0;
            decimal valor = 0;
            valor = cantidad * listaMoneda[PosicionMoneda(moneda)].CambioEuro;
            valor = valor / listaMoneda[PosicionMoneda(tipo)].CambioEuro;
            Dinero d = new Dinero(valor, tipo);
            return d;
        }

        public string ToString(TipoMoneda tipo)
        { 
            cantidad = ValorEn(tipo);
            string moneda_pantalla = "";
            int a = PosicionMoneda(tipo);
            return moneda_pantalla = Math.Round(cantidad, listaMoneda[a].Decimales) + listaMoneda[a].Simbolo;

          
        }

        public double ADouble()
        {
            double a = (double)cantidad;
            return a;
        }

        public int AEntero()
        {
            int a = (int)Math.Round(cantidad);
            return a;
        }

        public static void ActualizaListaInternet()
        {
            int i, j;
            string decimales = "";
            WebClient client = new WebClient();
            for (j = 0; j < listaMoneda.Count; j++)
            {
                if (listaMoneda[j].Tmoneda != TipoMoneda.Euro)
                {
                    string direccion = "https://www.x-rates.com/calculator/?from=EUR&to=" + listaMoneda[j].Codigo + "&amount = 1";
                    decimales = client.DownloadString(direccion);

                    string[] palabras = decimales.Split('<');
                    decimales = "";
                    //Busco las dos cadenas con el valor nuevo y los decimales que contienen, hay decimales separados
                    for (i = 0; i < palabras.Length; i++)
                    {

                        if (palabras[i].Contains("ccOutputRslt") == true)
                        {
                            decimales = palabras[i];
                        }
                        if (palabras[i].Contains("ccOutputTrail"))
                        {
                            decimales = decimales + ">" + palabras[i];
                        }
                    }

                    //Una vez que tengo los decimales, los transformo en una sola, con los dos decimales unidos.
                    string[] decimalescompletos = decimales.Split('>');
                    decimales = "";
                    for (i = 0; i < decimalescompletos.Length; i++)
                    {
                        if (i % 2 == 1)
                        {
                            decimales = decimales + decimalescompletos[i];
                        }

                    }
                    //Cambio el punto por la coma para que funcione y lo paso a un decimal.
                    decimales = decimales.Replace('.', ',');
                    decimal numero = decimal.Parse(decimales);
                    ActualizaCambio(listaMoneda[j].Tmoneda, numero);

                }
            }
        }

        //Operadores
        public static Dinero operator +(Dinero mon1, Dinero mon2)
        {
            if (mon1.moneda == mon2.moneda)
            {
                Dinero d = new Dinero(mon1.cantidad + mon2.cantidad, mon1.moneda);
                return d;
            }
            else
            {
                Dinero mon3;
                mon3 = mon2.ConvierteEn(mon1.moneda);
                Dinero d = new Dinero(mon1.cantidad + mon3.cantidad, mon1.moneda);
                return d;
            }

        }

        public static Dinero operator -(Dinero mon1, Dinero mon2)
        {
            if (mon1.moneda == mon2.moneda)
            {
                Dinero d = new Dinero(mon1.cantidad - mon2.cantidad, mon1.moneda);
                return d;
            }
            else
            {
                Dinero mon3;
                mon3 = mon2.ConvierteEn(mon1.moneda);
                Dinero d = new Dinero(mon1.cantidad - mon3.cantidad, mon1.moneda);
                return d;
            }

        }
        public static Dinero operator *(Dinero mon1, Dinero mon2)
        {
            if (mon1.moneda == mon2.moneda)
            {
                Dinero d = new Dinero(mon1.cantidad * mon2.cantidad, mon1.moneda);
                return d;
            }
            else
            {
                Dinero mon3;
                mon3 = mon2.ConvierteEn(mon1.moneda);
                Dinero d = new Dinero(mon1.cantidad * mon3.cantidad, mon1.moneda);
                return d;
            }
        }
        public static Dinero operator /(Dinero mon1, Dinero mon2)
        {
            if (mon1.moneda == mon2.moneda)
            {
                Dinero d = new Dinero(mon1.cantidad / mon2.cantidad, mon1.moneda);
                return d;
            }
            else
            {
                Dinero mon3;
                mon3 = mon2.ConvierteEn(mon1.moneda);
                Dinero d = new Dinero(mon1.cantidad / mon3.cantidad, mon1.moneda);
                return d;
            }
        }
        public static bool operator ==(Dinero mon1, Dinero mon2)
        {
            if (mon1.moneda == mon2.moneda && mon1.cantidad == mon2.cantidad)
            {
                return true;

            }
            else
            {
                Dinero mon3;
                mon3 = mon2.ConvierteEn(mon1.moneda);
                if (mon1.moneda == mon3.moneda && mon1.cantidad == mon3.cantidad)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

        }
        public static bool operator !=(Dinero mon1, Dinero mon2)
        {
            if (mon1.moneda == mon2.moneda && mon1.cantidad != mon2.cantidad)
            {
                return true;

            }
            else
            {
                Dinero mon3;
                mon3 = mon2.ConvierteEn(mon1.moneda);
                if (mon1.moneda == mon3.moneda && mon1.cantidad != mon3.cantidad)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

        }
        public static bool operator <(Dinero mon1, Dinero mon2)
        {
            if (mon1.moneda == mon2.moneda && mon1.cantidad < mon2.cantidad)
            {
                return true;

            }
            else
            {
                Dinero mon3;
                mon3 = mon2.ConvierteEn(mon1.moneda);
                if (mon1.moneda == mon3.moneda && mon1.cantidad < mon3.cantidad)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

        }
        public static bool operator >(Dinero mon1, Dinero mon2)
        {
            if (mon1.moneda == mon2.moneda && mon1.cantidad > mon2.cantidad)
            {
                return true;

            }
            else
            {
                Dinero mon3;
                mon3 = mon2.ConvierteEn(mon1.moneda);
                if (mon1.moneda == mon3.moneda && mon1.cantidad > mon3.cantidad)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

        }
        public static bool operator <=(Dinero mon1, Dinero mon2)
        {
            if (mon1.moneda == mon2.moneda && mon1.cantidad <= mon2.cantidad)
            {
                return true;

            }
            else
            {
                Dinero mon3;
                mon3 = mon2.ConvierteEn(mon1.moneda);
                if (mon1.moneda == mon3.moneda && mon1.cantidad <= mon3.cantidad)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

        }
        public static bool operator >=(Dinero mon1, Dinero mon2)
        {
            if (mon1.moneda == mon2.moneda && mon1.cantidad >= mon2.cantidad)
            {
                return true;

            }
            else
            {
                Dinero mon3;
                mon3 = mon2.ConvierteEn(mon1.moneda);
                if (mon1.moneda == mon3.moneda && mon1.cantidad >= mon3.cantidad)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

        }

    }

}
