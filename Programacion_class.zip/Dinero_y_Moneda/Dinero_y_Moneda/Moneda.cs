﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dinero_y_Moneda
{
    enum TipoMoneda
    {
        Euro, Dolar, Peso, British_Pound
    }
    class Moneda
    {
        //Atributo
        private TipoMoneda tmoneda;
        private int decimales;
        private string simbolo;
        private decimal cambioEuro;
        private string codigo;

        //Constructor
        public Moneda(TipoMoneda tmoneda, int decimales, string simbolo, decimal cambioEuro, string codigo)
        {
            this.tmoneda = tmoneda;

            if (decimales <= 4)
            {
                this.decimales = decimales;
            }
            else
            {
                throw new Exception("El número de decimales es demasiado grande");
            }

            if (simbolo != "")
            {
                this.simbolo = simbolo;
            }
            else
            {
                throw new Exception("El simbolo esta vacío");
            }

            if (cambioEuro > 0)
            {
                this.cambioEuro = cambioEuro;
            }
            else
            {
                throw new Exception("El cambio no puede ser negativo");
            }
            this.codigo = codigo;
        }
        
        //Propiedades
        public string Simbolo
        {
            get
            {
                return simbolo;
            }
        }
        public TipoMoneda Tmoneda
        {
            get
            {
                return tmoneda;
            }
        }
        public int Decimales
        {
            get
            {
                return decimales;
            }
        }
        public decimal CambioEuro
        {
            get
            {
                return cambioEuro;
            }
            set
            {
                if(value < 0)
                {
                    throw new Exception("El valor no puede se negativo");
                }
                else
                {
                    cambioEuro = value;
                }
               
               
            }
        }
        public string Codigo
        {
            get
            {
                return codigo;
            }
          
        }


    }
}