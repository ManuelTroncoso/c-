﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;

namespace Dinero_y_Moneda
{
    class Program
    {
        static void Main(string[] args)
        {
            Dinero.ActualizaListaInternet();
            Console.OutputEncoding = Encoding.UTF8;
            Console.WriteLine("Elige que opción quieres");
            Console.WriteLine("1 Peso a Dola");
            Console.WriteLine("2 Dola a Peso");
            Console.WriteLine("3 suma");
            Console.WriteLine("4 Resta");
            Console.WriteLine("5 Dividir");
            Console.WriteLine("6 Multiplicar");
            
            int a = int.Parse(Console.ReadLine());
            switch(a)
            {
                case 1:
                    {
                        Dinero d = new Dinero(5, TipoMoneda.Peso);
                        Console.WriteLine(d.ToString(TipoMoneda.Dolar));
                        Console.ReadKey();
                    } break;
                case 2:
                    {
                        Dinero d = new Dinero(5, TipoMoneda.British_Pound);
                        Console.WriteLine(d.ToString());
                        Console.WriteLine(d.ToString(TipoMoneda.Euro));
                        Console.ReadKey();
                    }break;
                case 3:
                    {
                        Dinero d = new Dinero(5, TipoMoneda.Peso);
                        Dinero d2 = new Dinero(5, TipoMoneda.Dolar);
                        Dinero d3 = d + d2;
                        Console.WriteLine(d3.ToString());
                        Console.ReadKey();
                    }break;
                case 4:
                    {

                        Dinero d = new Dinero(5, TipoMoneda.Dolar);
                        Dinero d2 = new Dinero(5, TipoMoneda.Peso);
                        Dinero d3 = d - d2;
                        Console.WriteLine(d3.ToString());
                        Console.ReadKey();
                    }break;
                case 5:
                    {

                        Dinero d = new Dinero(5, TipoMoneda.Dolar);
                        Dinero d2 = new Dinero(5, TipoMoneda.Peso);
                        Dinero d3 = d / d2;
                        Console.WriteLine(d3.ToString());
                        Console.ReadKey();
                    }
                    break;
                case 6:
                    {

                        Dinero d = new Dinero(5, TipoMoneda.Dolar);
                        Dinero d2 = new Dinero(5, TipoMoneda.Peso);
                        Dinero d3 = d * d2;
                        Console.WriteLine(d3.ToString());
                        Console.ReadKey();
                    }break;
            }

        }
    }
}
