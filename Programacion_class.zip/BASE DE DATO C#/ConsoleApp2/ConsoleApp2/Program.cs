﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;

namespace ConsoleApp2
{
    class Program
    {
        /// <summary>
        /// Actualiza los datos de una base de datos, ACCESS
        /// </summary>
        static void ActualizarDato()
        {
            //Primero nos conectamos
            OleDbConnection connection = new OleDbConnection("Provider = Microsoft.Jet.OLEDB.4.0; Data Source=C:\\Users\\Manu\\Desktop\\BASE DE DATO C#\\Base de dato1.mdb;Persist Security Info = False;");
            //Abrimos conexión
            connection.Open();

            string nombre;
            int ID, a;
            Console.WriteLine("1. Cambiar el nombre");
            Console.WriteLine("2. Cambiar la fecha");
            a = int.Parse(Console.ReadLine());
           
            switch (a)
            {
                case 1:
                    {
                        Console.WriteLine("Introduce el nombre que quieres actualizar");
                        nombre = Console.ReadLine();
                        Console.WriteLine("Introduce la ID");
                        ID = int.Parse(Console.ReadLine());
                        // Introducimos la orden que queremos
                        OleDbCommand command = new OleDbCommand("UPDATE Table1 SET nombre = '" + nombre + "' WHERE Id = " + ID + ";", connection);
                        //No se lo que hacia xd
                        command.ExecuteNonQuery();
                    }
                    break;
            }
          
        }
        static void Main(string[] args)
        {
            //OleDbCommand; // MAsndar comando
            //OleDbDataReader; // Para leer
            //OleDbConnection connection = new OleDbConnection("Provider = Microsoft.Jet.OLEDB.4.0; Data Source=C:\\Users\\Manu\\Desktop\\BASE DE DATO C#\\Base de dato1.mdb;Persist Security Info = False;");
            //connection.Open();
            //OleDbCommand command = new OleDbCommand("UPDATE Table1 SET Nombre = 'Alberto' WHERE Id = 2;", connection);
            //command.ExecuteNonQuery();

            //Console.Write("Select ");
            //string a = Console.ReadLine();
            //Console.Write("from ");
            //string b = Console.ReadLine();
            
            //OleDbCommand command2 = new OleDbCommand("select " + a + "from " + b + ";", connection);
            //OleDbDataReader reader = command2.ExecuteReader();

            //while (reader.Read())
            //{
            //    Console.WriteLine(reader.GetInt32(0));
            //    Console.WriteLine(reader.GetString(1));
            //    Console.WriteLine(reader.GetDateTime(2));
            //}
            //Console.ReadKey();
            int i;
            Console.WriteLine("1.- Actualiza datos");
            i = int.Parse(Console.ReadLine());
            switch (i)
            {
                case 1:
                    {
                       
                        ActualizarDato();
                    }break;
            }

        }
    }
}
