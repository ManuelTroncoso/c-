﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.IO;

namespace Tres_en_raya_
{
    class Program
    {
        static void JugadorVsCPUHight (_3EnRaya tablero)
        {
            int turno = 1;
            int pos;

            while (tablero.QuedanMovimientos() && !tablero.GanaJugador1() && !tablero.GanaJugador2())
            {
                Console.Clear();
                tablero.DibujaTablero();
                if (turno == 1)
                {
                    pos = -1;
                    while(pos == -1)
                    {
                        pos = tablero.CompruebaColumnaIA();
                        if (pos == -1)
                        {
                            pos = tablero.CompruebaDiagonalIA00();
                        }
                        if(pos == -1)
                        {
                            pos = tablero.CompruebaDiagonalIA20();
                        }
                        if (pos == -1)
                        {
                            pos = tablero.CompruebaFilaIA(); 
                        }
                        break;

                    }
                    if(pos!= -1 && tablero.MovimientoValido(pos) == true)
                    {
                        tablero.MueveJugador1(pos);
                    }
                    else
                    {
                        tablero.MueveOrdenador1();
                    }
                    turno = 2;
                }
                else
                {
                    pos = int.Parse(Console.ReadLine());
                    tablero.MueveJugador2(pos);
                    turno = 1;
                }
                Console.Clear();
                tablero.DibujaTablero();

            }
        }
        static void JugadorVSJugador(_3EnRaya tablero)
        {
            
            int turno = 1;
            int pos;

            while (tablero.QuedanMovimientos() && !tablero.GanaJugador1() && !tablero.GanaJugador2())
            {
                Console.Clear();
                tablero.DibujaTablero();
                if (turno == 1)
                {
                    pos = int.Parse(Console.ReadLine());
                    tablero.MueveJugador1(pos);
                    turno = 2;
                }
                else
                {
                    pos = int.Parse(Console.ReadLine());
                    tablero.MueveJugador2(pos);
                    turno = 1;
                }
                Console.Clear();
                tablero.DibujaTablero();

            }

            if (tablero.GanaJugador1())
            {
                Console.WriteLine("GANA EL JUGADOR 1");
            }
            else
            {
                if (tablero.GanaJugador2())
                {
                    Console.WriteLine("GANA EL JUGADOR 2");
                }
                else
                {
                    Console.WriteLine("TABLAS");
                }
            }
        }
        static void JugadorVSJugadorOnline(_3EnRaya tablero)
        {
            TcpListener servidor = new TcpListener(9999);
            servidor.Start();
            TcpClient cliente = servidor.AcceptTcpClient();
            NetworkStream ns = cliente.GetStream();
            StreamWriter sw = new StreamWriter(ns);
            StreamReader sr = new StreamReader(ns);
            int texto;
            int turno = 1;
            int pos;

            while (tablero.QuedanMovimientos() && !tablero.GanaJugador1() && !tablero.GanaJugador2())
            {
                Console.Clear();
                tablero.DibujaTablero();
                if (turno == 1)
                {
                    pos = int.Parse(Console.ReadLine());
                    tablero.MueveJugador1(pos);
                    sw.WriteLine(pos);

                    turno = 2;
                }
                else
                {
                          
                    pos = int.Parse(sr.ReadLine());

                    tablero.MueveJugador2(pos);
                    turno = 1;
                }
                sw.Flush();
                Console.Clear();
                tablero.DibujaTablero();

            }
            sw.Close();
            sr.Close();
            ns.Close();
            cliente.Close();
            if (tablero.GanaJugador1())
            {
                Console.WriteLine("GANA EL JUGADOR 1");
            }
            else
            {
                if (tablero.GanaJugador2())
                {
                    Console.WriteLine("GANA EL JUGADOR 2");
                }
                else
                {
                    Console.WriteLine("TABLAS");
                }
            }
        }
        static void JugadorVSJugadorCliente(_3EnRaya tablero)
        {
                TcpClient cliente = new TcpClient("172.30.10.72", 9999);
                NetworkStream ns = cliente.GetStream();
                StreamReader sr = new StreamReader(ns);
                StreamWriter sw = new StreamWriter(ns);
                Console.WriteLine("conectado!!");
                int turno = 1;
                int pos;


                while (tablero.QuedanMovimientos() && !tablero.GanaJugador1() && !tablero.GanaJugador2())
                {
                    
                    Console.Clear();
                    tablero.DibujaTablero();
                    switch (turno)
                    {
                        case 1: Console.ForegroundColor = ConsoleColor.Blue; break;
                        case 2: Console.ForegroundColor = ConsoleColor.Red; break;
                        default: Console.ForegroundColor = ConsoleColor.Gray; break;
                    }
                    Console.WriteLine("Turno Jugador " + turno + ":");
                    Console.ForegroundColor = ConsoleColor.Gray;
                    if (turno == 1)
                    {
                        pos = int.Parse(sr.ReadLine());
                        while (!tablero.MovimientoValido(pos))
                        {
                            pos = int.Parse(Console.ReadLine());
                        }
                        tablero.MueveJugador1(pos);
                        turno = 2;

                    }
                    else
                    {


                        pos = int.Parse(Console.ReadLine());
                        sw.WriteLine(pos);
                        while (!tablero.MovimientoValido(pos))
                        {
                            pos = int.Parse(Console.ReadLine());


                        }
                        tablero.MueveJugador2(pos);
                        turno = 1;
                    }
                    sw.Flush();
                    Console.Clear();
                    tablero.DibujaTablero();
                    if (!tablero.GanaJugador1() && !tablero.GanaJugador2())
                    {
                        Console.WriteLine("Turno Jugador " + turno + ":");
                    }
                    Console.ForegroundColor = ConsoleColor.Gray;
                }

                if (tablero.GanaJugador1())
                {
                    
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.WriteLine("Win P1");

                   
                }
                else
                {
                    if (tablero.GanaJugador2())
                    {
                      

                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Win P2");

                     
                    }
                    else
                    {
                        
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.Write("Emp");
                        Console.ForegroundColor = ConsoleColor.Blue;
                        Console.Write("ate");


                    }
                    sr.Close();
                    sw.Close();

                    ns.Close();

                    cliente.Close();

                    Console.ReadKey();
                }
            
        }
        static void Main(string[] args)
        {
            _3EnRaya tablero = new _3EnRaya();

            //JugadorVSJugadorOnline(tablero);
            JugadorVsCPUHight(tablero);
            Console.ReadKey();
        }
    }
}
