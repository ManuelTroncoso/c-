﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tres_en_raya_
{
    class _3EnRaya
    {
        //Atributo
        private int[,] tablero;
        private Random mov = new Random();

        //Constructor
        public _3EnRaya()
        {
            tablero = new int[3, 3];
        }

        //Métodos
        public void TransformaPosicion(int posicion, out int fila, out int columna)
        {
            switch (posicion)
            {
                case 1: columna = 0; fila = 0; break;
                case 2: columna = 1; fila = 0; break;
                case 3: columna = 2; fila = 0; break;
                case 4: columna = 0; fila = 1; break;
                case 5: columna = 1; fila = 1; break;
                case 6: columna = 2; fila = 1; break;
                case 7: columna = 0; fila = 2; break;
                case 8: columna = 1; fila = 2; break;
                case 9: columna = 2; fila = 2; break;
                default: throw new Exception("ERROR");
            }

        }
        /// <summary>
        /// Le pasa las filas y las columnas y te devuelve una posicion, en caso de la que no exista esa posición devuelve -1
        /// </summary>
        /// <param name="fila"></param>
        /// <param name="columna"></param>
        /// <returns></returns>
        public int TransdormaFilasColumna(int fila, int columna)
        {
            int posicion;
            if (columna == 0)
            {
                if (fila == 0)
                {
                    return posicion = 1;
                }
                else
                {
                    if (fila == 1)
                    {
                        return posicion = 4;
                    }
                    else
                    {
                        if (fila == 2)
                        {
                            return posicion = 7;
                        }
                    }
                }
            }
            else
            {
                if (columna == 1)
                {
                    if (fila == 0)
                    {
                        return posicion = 2;
                    }
                    else
                    {
                        if (fila == 1)
                        {
                            return posicion = 5;
                        }
                        else
                        {
                            if (fila == 2)
                            {
                                return posicion = 8;
                            }
                        }
                    }
                }
                else
                {
                    if (columna == 2)
                    {
                        if (fila == 0)
                        {
                            return posicion = 3;
                        }
                        else
                        {
                            if (fila == 1)
                            {
                                return posicion = 6;
                            }
                            else
                            {
                                if (fila == 2)
                                {
                                    return posicion = 9;
                                }
                            }
                        }
                    }
                }
            }
            return -1;
        }

        public void MueveJugador1(int posicion)
        {
            int fila, columna;
            TransformaPosicion(posicion, out fila, out columna);
            if (MovimientoValido(posicion))
            {
                tablero[fila, columna] = 1;
            }
            else
            {
                throw new Exception("ERROR");
            }
        }

        public void MueveJugador2(int posicion)
        {
            int fila, columna;
            TransformaPosicion(posicion, out fila, out columna);
            if (MovimientoValido(posicion))
            {
                tablero[fila, columna] = 2;
            }
            else
            {
                throw new Exception("ERROR");
            }
        }

        public bool MovimientoValido (int pos)
        {
            int fila, columna;
            TransformaPosicion(pos, out fila, out columna);
            if (tablero[fila, columna] == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void MueveOrdenador1()
        {

            int posicion = mov.Next(1, 10);
            int fila, columna, i = 0;
            TransformaPosicion(posicion, out fila, out columna);
            while (i == 0)
            {
                posicion = mov.Next(1, 10);
                TransformaPosicion(posicion, out fila, out columna);
                if (MovimientoValido(posicion))
                {
                    tablero[fila, columna] = 1;
                    i = 1;
                }
            }

        }
        
        /// <summary>
        /// Comprueba las filas cuando el rival esta a punto de ganar, te devuelve la posicion donde se tiene que colocar
        /// si no esta a punto de ganar devuelve "-1"
        /// </summary>
        public int CompruebaFilaIA()
        {
            int fila, columna, i, j, pos;
            for (i = 0; i < tablero.GetLength(0); i++)
            {

                for (j = 0; j < tablero.GetLength(1) - 1;)
                {
                    if (tablero[i,j] == 2)
                    {
                        j++;
                        if(tablero[i,j] == 2)
                        {
                            fila = i;
                            columna = j + 1;
                            pos = TransdormaFilasColumna(fila, columna);
                            return pos;
                        }
                        else
                        {
                            j++;
                            if(tablero[i, j] ==2)
                            {
                                fila = i;
                                columna = j - 1;
                                pos = TransdormaFilasColumna(fila, columna);
                                return pos;
                            }
                        }
                    }
                    else
                    {
                        
                        j++;
                        if(tablero[i,j] == 2)
                        {
                            j = 1;
                            j++;
                            if(tablero[i, j] == 2)
                            {
                                fila = i;
                                columna = j - 2;
                                pos = TransdormaFilasColumna(fila, columna);
                                return pos;
                            }
                        }
                        j = 2;
                    }
                }

            }
            return -1;

        }
        public int CompruebaColumnaIA()
        {
            
            int fila, columna, i, j, pos;
            for (i = 0; i < tablero.GetLength(0);i++)
            {
                for (j = 0; j < tablero.GetLength(1) - 1;)
                {
                    if(tablero[j,i] == 2)
                    {
                        j++;
                        if(tablero[j,i] == 2)
                        {
                            fila = j + 1;
                            columna = i;
                            pos = TransdormaFilasColumna(fila, columna);
                            return pos;
                        }
                        else
                        {
                            j++;
                            if (tablero[j, i] == 2)
                            {
                                fila = j - 1;
                                columna = i;
                                pos = TransdormaFilasColumna(fila, columna);
                                return pos;
                            }
                        }
                    }
                    else
                    {
                        j++;
                        if(tablero[j,i] == 2)
                        {
                            j++;
                            if(tablero[j,i] == 2)
                            {
                                fila = j - 1;
                                columna = i;
                                pos = TransdormaFilasColumna(fila, columna);
                                return pos;
                            }
                        }
                        j = 2;
                    }
                }

            }
            return -1;
        }
        public int CompruebaDiagonalIA00()
        {
            int fila, columna, i, j, pos;
            for (i = 0; i < tablero.GetLength(0); i++)
            {
                for (j = 0; j < tablero.GetLength(1) - 1;)
                {
                    if(j == i)
                    {
                        if (tablero[j, i] == 2)
                        {
                            j++;
                            i++;
                            if(tablero[j,i] == 2)
                            {
                                fila = i + 1;
                                columna = j + 1;
                                pos = TransdormaFilasColumna(fila, columna);
                                return pos;
                            }
                            else
                            {
                                i++;
                                j++;
                                if (tablero[j, i] == 2)
                                {
                                    fila = i - 1;
                                    columna = j - 1;
                                    pos = TransdormaFilasColumna(fila, columna);
                                    return pos;
                                }
                            }
                        }
                        else
                        {
                            j++;
                            i++;
                            if (tablero[i, j] == 2)
                            {
                                i++;
                                j++;
                                if (tablero[i, j] == 2)
                                {
                                    fila = i - 2;
                                    columna = j - 2;
                                    pos = TransdormaFilasColumna(fila, columna);
                                    return pos;
                                }
                            }
                            j = 2;
                            i = 2;
                        }
                    }
                   
                }
            }
            return -1;
        }
        public int CompruebaDiagonalIA20()
        {
            int fila, columna, i, j, pos;
            for (i = 0; i < tablero.GetLength(0); i++)
            {
                for (j = 0; j < tablero.GetLength(1);)
                {
                    if(i+j == 2)
                    {
                        if(tablero[i,j] == 2)
                        {
                            j--;
                            i++;
                            if(tablero[i,j] == 2)
                            {
                                columna = i-1;
                                fila = j+1;
                                pos = TransdormaFilasColumna(fila, columna);
                                return pos;
                            }
                            else
                            {
                                j--;
                                i++;
                                if (tablero[i, j] == 2)
                                {
                                    fila = 1;
                                    columna = 1;
                                    pos = TransdormaFilasColumna(fila, columna);
                                    return pos;
                                }
                            }
                        }
                        else
                        {
                            j--;
                            i++;
                            if (tablero[i, j] == 2)
                            {
                                i++;
                                j--;
                                
                                if (tablero[i, j] == 2)
                                {
                                    fila = i - 2;
                                    columna = j + 2;
                                    pos = TransdormaFilasColumna(fila, columna);
                                    return pos;
                                }
                            }
                            i = 2;
                            j = 2;
                        }
                        
                    }
                    j++;
                }
               
                

            }
            return -1;
        }
        public void MueveOrdenador2()
        {
            
            int posicion = mov.Next(1, 10);
            int fila, columna, i = 0;
            TransformaPosicion(posicion, out fila, out columna);
            while (i == 0)
            {
                posicion = mov.Next(1, 10);
                TransformaPosicion(posicion, out fila, out columna);
                if (MovimientoValido(posicion))
                {
                    tablero[fila, columna] = 2;
                    i = 1;
                }
            }

        }
        public void Inicial()
        {
            tablero = new int[3,3];
        }
        public bool QuedanMovimientos()
        {
            int i, j;

            for(i = 0; i<tablero.GetLength(0); i++)
            {
                for(j = 0; j < tablero.GetLength(1) - 1; j++)
                {
                    if(tablero[i,j] == 0)
                    {
                        return true;
                    }
                }
            }
            return false;
        }
        public bool GanaJugador1()
        {
            int i, j;
            int contador;
            for (i = 0; i < tablero.GetLength(0); i++)
            {
                contador = 0;
                for (j = 0; j < tablero.GetLength(1); j++)
                {
                    if (tablero[i, j] == 1)
                    {
                        contador++;
                    }
                 
                }
                if(contador == 3)
                {
                    return true;
                }
            }
            for (i = 0; i < tablero.GetLength(0); i++)
            {
                contador = 0;
                for (j = 0; j < tablero.GetLength(1); j++)
                {
                    if (tablero[j, i] == 1)
                    {
                        contador++;
                    }

                }
                if (contador == 3)
                {
                    return true;
                }
            }

            contador = 0;
            for (i = 0; i < tablero.GetLength(0); i++)
            {               
                for (j = 0; j < tablero.GetLength(1); j++)
                {
                    if (i == j)
                    {
                        if (tablero[j, i] == 1)
                        {
                            contador++;
                        }
                    }

                }
             
            }
            if (contador == 3)
            {
                return true;
            }


            contador = 0;
            for (i = 0; i < tablero.GetLength(0); i++)
            {
               
                for (j = 0; j < tablero.GetLength(1); j++)
                {
                    if (i + j == 2)
                    {
                        if (tablero[j, i] == 1)
                        {
                            contador++;
                        }
                    }

                }
              

            }
            if (contador == 3)
            {
                return true;
            }


            return false;

        }
        public bool GanaJugador2()
        {
            int i, j;
            for (i = 0; i < tablero.GetLength(0); i++)
            {
                int contador = 0;
                for (j = 0; j < tablero.GetLength(1); j++)
                {
                    if (tablero[i, j] == 2)
                    {
                        contador++;
                    }

                }
                if (contador == 3)
                {
                    return true;
                }
            }
            for (i = 0; i < tablero.GetLength(0); i++)
            {
                int contador = 0;
                for (j = 0; j < tablero.GetLength(1); j++)
                {
                    if (tablero[j, i] == 2)
                    {
                        contador++;
                    }

                }
                if (contador == 3)
                {
                    return true;
                }
            }
            for (i = 0; i < tablero.GetLength(0); i++)
            {
                int contador = 0;
                for (j = 0; j < tablero.GetLength(1); j++)
                {
                    if (i == j)
                    {
                        if (tablero[j, i] == 2)
                        {
                            contador++;
                        }
                    }

                }
                if (contador == 3)
                {
                    return true;
                }

            }
            for (i = 0; i < tablero.GetLength(0); i++)
            {
                int contador = 0;
                for (j = 0; j < tablero.GetLength(1); j++)
                {
                    if (i + j == 2)
                    {
                        if (tablero[j, i] == 2)
                        {
                            contador++;
                        }
                    }

                }
                if (contador == 3)
                {
                    return true;
                }

            }
            return false;

        }
        public void DibujaTablero()
        {
            int i, j;

            for (i = 0; i < tablero.GetLength(0); i++)
            {

                Console.Write("|");
                for (j = 0; j < tablero.GetLength(1) - 1; j++)
                {
                    if(tablero[i,j] == 1)
                    {
                        Console.Write(" " + "X" + " |");
                    }
                    else
                    {
                        if (tablero[i, j] == 2)
                        {
                                Console.Write(" " + "O" + " |");
                        }
                        else
                        {
                            Console.Write(" " + " " + " |");
                        }
                    }
                    
                    

                }

                if (tablero[i, j] == 1)
                {
                    Console.Write(" " + "X" + " ");
                }
                else
                {
                    if (tablero[i, j] == 2)
                    {
                        Console.Write(" " + "O" + " ");
                    }
                    else
                    {
                        Console.Write(" " + " " + " ");
                    }
                }
                Console.WriteLine("|");
                
                Console.Write("|___|___|___");
                Console.WriteLine("|");



            }
        }


    }
}
