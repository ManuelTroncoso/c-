﻿namespace Quinto_Ejercicio
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Pulgadas = new System.Windows.Forms.Label();
            this.TBpulgadas = new System.Windows.Forms.TextBox();
            this.Centrimetro = new System.Windows.Forms.Label();
            this.TBcentimetros = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // Pulgadas
            // 
            this.Pulgadas.AutoSize = true;
            this.Pulgadas.Location = new System.Drawing.Point(27, 36);
            this.Pulgadas.Name = "Pulgadas";
            this.Pulgadas.Size = new System.Drawing.Size(51, 13);
            this.Pulgadas.TabIndex = 0;
            this.Pulgadas.Text = "Pulgadas";
            // 
            // TBpulgadas
            // 
            this.TBpulgadas.Location = new System.Drawing.Point(97, 29);
            this.TBpulgadas.Name = "TBpulgadas";
            this.TBpulgadas.Size = new System.Drawing.Size(141, 20);
            this.TBpulgadas.TabIndex = 1;
            this.TBpulgadas.TextChanged += new System.EventHandler(this.TBpulgadas_TextChanged);
            // 
            // Centrimetro
            // 
            this.Centrimetro.AutoSize = true;
            this.Centrimetro.Location = new System.Drawing.Point(27, 111);
            this.Centrimetro.Name = "Centrimetro";
            this.Centrimetro.Size = new System.Drawing.Size(64, 13);
            this.Centrimetro.TabIndex = 2;
            this.Centrimetro.Text = "Centímetros";
            // 
            // TBcentimetros
            // 
            this.TBcentimetros.Location = new System.Drawing.Point(97, 104);
            this.TBcentimetros.Name = "TBcentimetros";
            this.TBcentimetros.Size = new System.Drawing.Size(141, 20);
            this.TBcentimetros.TabIndex = 3;
            this.TBcentimetros.TextChanged += new System.EventHandler(this.TBcentimetros_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(269, 168);
            this.Controls.Add(this.TBcentimetros);
            this.Controls.Add(this.Centrimetro);
            this.Controls.Add(this.TBpulgadas);
            this.Controls.Add(this.Pulgadas);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Pulgadas;
        private System.Windows.Forms.TextBox TBpulgadas;
        private System.Windows.Forms.Label Centrimetro;
        private System.Windows.Forms.TextBox TBcentimetros;
    }
}

