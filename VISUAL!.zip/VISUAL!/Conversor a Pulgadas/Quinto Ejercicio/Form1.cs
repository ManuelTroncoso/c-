﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quinto_Ejercicio
{
    public partial class Form1 : Form
    {
        //Atributo
        private double conversion = 2.54;
        private bool modificar;
        private bool error;
        public Form1()
        {
            InitializeComponent();
        }

        private void TBpulgadas_TextChanged(object sender, EventArgs e)
        {
            if(modificar == false)
            {
                modificar = true;
                double solucion;
                if(error = double.TryParse(TBpulgadas.Text, out solucion))
                {
                    solucion = solucion * conversion;
                    TBcentimetros.Text = solucion.ToString();
                }
                else
                {
                    TBcentimetros.Text = "";
                }
                modificar = false;
                
            }
            
           
        }

        private void TBcentimetros_TextChanged(object sender, EventArgs e)
        {

            if (modificar == false)
            {
                modificar = true;
                double solucion;
                if (error = double.TryParse(TBcentimetros.Text, out solucion))
                {
                    solucion = solucion * conversion;
                    TBpulgadas.Text = solucion.ToString();
                }
                else
                {
                    TBpulgadas.Text = "";
                }
                modificar = false;
            }
        }
    }
}
