﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Estadistica_texto
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void textBoxTexto_TextChanged(object sender, EventArgs e)
        {
            string texto = textBoxTexto.Text;
            string[] palabras = texto.Split(' ');
            string vocales2 = "aeiou";
            int i,j, k, nletras = 0, npalabras = 0, nvocales = 0, nconsonantes = 0, nespacios = 0;
            for (i = 0; i < palabras.Length; i++)
            {
                if(palabras[i] != "")
                {
                    npalabras++;
                }
            }
            for(i= 0; i < texto.Length; i++)
            {
                if (char.IsLetter(texto[i]))
                {
                    nletras++;
                    if (vocales2.Contains(texto[i]))
                    {
                        nvocales++;
                    }
                    else
                    {
                        nconsonantes++;
                    }
                }
                else
                {
                    if(texto[i] == ' ')
                    {
                        nespacios++;
                    }
                }
            }
            label1.Text = "letras: " + nletras.ToString();
            label2.Text = "palabras: " + npalabras.ToString();
            label3.Text = "vocales: "+nvocales.ToString();
            label4.Text = "consonantes"+nconsonantes.ToString();
            label5.Text = "espacios: " + nespacios.ToString();
        }


    }
}
