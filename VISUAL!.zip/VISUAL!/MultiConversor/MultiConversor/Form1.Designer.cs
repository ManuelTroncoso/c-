﻿namespace MultiConversor
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.radioButtonMV = new System.Windows.Forms.RadioButton();
            this.radioButtonKMV = new System.Windows.Forms.RadioButton();
            this.radioButtonMMV = new System.Windows.Forms.RadioButton();
            this.radioButtonCMV = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(15, 27);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(90, 20);
            this.textBox1.TabIndex = 0;
            this.textBox1.Text = "0";
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(161, 27);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(83, 20);
            this.textBox2.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Valor:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(157, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Resultado: ";
            // 
            // radioButtonMV
            // 
            this.radioButtonMV.AutoSize = true;
            this.radioButtonMV.Location = new System.Drawing.Point(161, 77);
            this.radioButtonMV.Name = "radioButtonMV";
            this.radioButtonMV.Size = new System.Drawing.Size(57, 17);
            this.radioButtonMV.TabIndex = 4;
            this.radioButtonMV.TabStop = true;
            this.radioButtonMV.Text = "Metros";
            this.radioButtonMV.UseVisualStyleBackColor = true;
            this.radioButtonMV.CheckedChanged += new System.EventHandler(this.radioButtonMV_CheckedChanged);
            // 
            // radioButtonKMV
            // 
            this.radioButtonKMV.AutoSize = true;
            this.radioButtonKMV.Location = new System.Drawing.Point(161, 54);
            this.radioButtonKMV.Name = "radioButtonKMV";
            this.radioButtonKMV.Size = new System.Drawing.Size(73, 17);
            this.radioButtonKMV.TabIndex = 5;
            this.radioButtonKMV.TabStop = true;
            this.radioButtonKMV.Text = "Kilómetros";
            this.radioButtonKMV.UseVisualStyleBackColor = true;
            this.radioButtonKMV.CheckedChanged += new System.EventHandler(this.radioButtonKMV_CheckedChanged);
            // 
            // radioButtonMMV
            // 
            this.radioButtonMMV.AutoSize = true;
            this.radioButtonMMV.Location = new System.Drawing.Point(161, 123);
            this.radioButtonMMV.Name = "radioButtonMMV";
            this.radioButtonMMV.Size = new System.Drawing.Size(71, 17);
            this.radioButtonMMV.TabIndex = 6;
            this.radioButtonMMV.TabStop = true;
            this.radioButtonMMV.Text = "Milimetros";
            this.radioButtonMMV.UseVisualStyleBackColor = true;
            this.radioButtonMMV.CheckedChanged += new System.EventHandler(this.radioButtonMMV_CheckedChanged);
            // 
            // radioButtonCMV
            // 
            this.radioButtonCMV.AutoSize = true;
            this.radioButtonCMV.Location = new System.Drawing.Point(161, 100);
            this.radioButtonCMV.Name = "radioButtonCMV";
            this.radioButtonCMV.Size = new System.Drawing.Size(83, 17);
            this.radioButtonCMV.TabIndex = 7;
            this.radioButtonCMV.TabStop = true;
            this.radioButtonCMV.Text = "Centrimetros";
            this.radioButtonCMV.UseVisualStyleBackColor = true;
            this.radioButtonCMV.CheckedChanged += new System.EventHandler(this.radioButtonCMV_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.radioButtonCMV);
            this.Controls.Add(this.radioButtonMMV);
            this.Controls.Add(this.radioButtonKMV);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.radioButtonMV);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton radioButtonMV;
        private System.Windows.Forms.RadioButton radioButtonKMV;
        private System.Windows.Forms.RadioButton radioButtonMMV;
        private System.Windows.Forms.RadioButton radioButtonCMV;
    }
}

