﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MultiConversor
{
    public partial class Form1 : Form
    {
        int opcion = 1;
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

            switch (opcion)
            {
                case 1:
                    {
                        textBox2.Text = textBox1.Text;
                    }
                    break;
                case 2:
                    {
                        textBox2.Text = (double.Parse(textBox1.Text) * 0.001).ToString();
                    } break;
                case 3:
                    {
                        textBox2.Text = (double.Parse(textBox1.Text) * 100).ToString();
                    }
                    break;
                case 4:
                    {
                        textBox2.Text = (double.Parse(textBox1.Text) * 1000).ToString();
                    }break;
            }
        }
        private void radioButtonKMV_CheckedChanged(object sender, EventArgs e)
        {
            textBox2.Text = (double.Parse(textBox1.Text) * 0.001).ToString();
            opcion = 2;
        }

        private void radioButtonMV_CheckedChanged(object sender, EventArgs e)
        {
            textBox2.Text = textBox1.Text;
        }

        private void radioButtonCMV_CheckedChanged(object sender, EventArgs e)
        {

            textBox2.Text = (double.Parse(textBox1.Text) * 100).ToString();
            opcion = 3;
        }

        private void radioButtonMMV_CheckedChanged(object sender, EventArgs e)
        {
            opcion = 4;
            textBox2.Text = (double.Parse(textBox1.Text) * 1000).ToString();
        }
    }
}

