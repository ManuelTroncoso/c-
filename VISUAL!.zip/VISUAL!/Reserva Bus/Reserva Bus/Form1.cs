﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Reserva_Bus
{
    public partial class Form1 : Form
    {
        List<Button> listabuttom = new List<Button>();
        int altura = 12, x = 12;
        int reserva = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            for (int i = 1; i < 65; i++)
            {
                if (i == 17 || i == 33 || i == 49)
                {
                    altura = 12;
                    if (i == 33)
                    {
                        x = x + 33;
                    }
                    x = x + 33;
                }
                Button b = new Button();
                b.Text = i.ToString();
                b.Location = new Point(x, altura);
                b.Size = new Size(30, 30);
                b.BackColor = Color.LightGreen;
                b.Click += new EventHandler(button_Click);
                panel1.Controls.Add(b);
                altura = altura + 33;
                listabuttom.Add(b);
            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            int contador = 0;
            for (int i = 0; i < listabuttom.Count; i++)
            {
                if (textBox1.Text != "" && listabuttom[i].BackColor == Color.Orange)
                {
                    buttonReserva.Enabled = true;
                    contador = 1;
                }
            }
            if(contador == 0)
            {
                buttonReserva.Enabled = false;
            }
        }

        private void buttonReserva_Click(object sender, EventArgs e)
        {
            double numeros = 0;
            string numeroReserva = "";
            int i;
            for (i= 0; i < listabuttom.Count; i++)
            {
                if(listabuttom[i].BackColor == Color.Orange)
                {
                    listabuttom[i].BackColor = Color.Red;
                    numeros++;
                    numeroReserva = numeroReserva + (i + 1).ToString() + "-";
                    //numeroReserva = numeroReserva + listabuttom[i].Text + "-";
                }
            }
            listView1.Items.Add(textBox1.Text);
            listView1.Items[reserva].SubItems.Add(numeroReserva.TrimEnd('-'));
            listView1.Items[reserva].SubItems.Add((numeros * 1.10).ToString());
            reserva++;
            buttonReserva.Enabled = false;
        }


        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            if (b.BackColor == Color.Orange)
            {
                b.BackColor = Color.LightGreen;
            }
            else
            {
                if(b.BackColor == Color.LightGreen)
                {
                    b.BackColor = Color.Orange;
                }
            }
            int contador = 0;
            for (int i = 0; i < listabuttom.Count; i++)
            {
                if (textBox1.Text != "" && listabuttom[i].BackColor == Color.Orange)
                {
                    buttonReserva.Enabled = true;
                    contador = 1;
                }
            }
            if (contador == 0)
            {
                buttonReserva.Enabled = false;
            }

        }

    }

}
