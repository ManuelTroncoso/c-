﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SuperTest
{
    public partial class Form1 : Form
    {
        int contador = 1;
        int aciertos = 0;
        public Form1()
        {
            InitializeComponent();
            label1.Text = "Vamos a comenzar el test, porfavor haz click en continuar";
            radioButton1.Visible = false;
            radioButton2.Visible = false;
            radioButton3.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            switch (contador)
            {
                case 1:
                    {
                        radioButton1.Visible = true;
                        radioButton2.Visible = true;
                        radioButton3.Visible = true;
                        label1.Text = "Primera pregunta";
                        contador++;
                    }
                    break;

                case 2:
                    {
                        if (radioButton1.Checked == true || radioButton2.Checked == true || radioButton3.Checked == true)
                        {
                            if (radioButton1.Checked)
                            {
                                aciertos++;
                                listBox1.Items.Add("Respuesta correcta");
                            }
                            else
                            {
                                listBox1.Items.Add("Respuesta erronea");
                            }
                        }
                        else
                        {
                            listBox1.Items.Add("Pregunta no respondida");
                        }
                        label1.Text = "Segunda pregunta";
                        contador++;
                    }
                    break;

                case 3:
                    {
                        if (radioButton1.Checked == true || radioButton2.Checked == true || radioButton3.Checked == true)
                        {
                            if (radioButton1.Checked)
                            {
                                aciertos++;
                                listBox1.Items.Add("Respuesta correcta");
                            }
                            else
                            {
                                listBox1.Items.Add("Respuesta erronea");
                            }
                        }
                        else
                        {
                            listBox1.Items.Add("Pregunta no respondida");
                        }
                        contador++;
                        label1.Text = "Tercera pregunta";
                    }
                    break;

                case 4:
                    {
                        if (radioButton1.Checked == true || radioButton2.Checked == true || radioButton3.Checked == true)
                        {
                            if (radioButton1.Checked)
                            {
                                aciertos++;
                                listBox1.Items.Add("Respuesta correcta");
                            }
                            else
                            {
                                listBox1.Items.Add("Respuesta erronea");
                            }
                        }
                        else
                        {
                            listBox1.Items.Add("Pregunta no respondida");
                        }
                        label1.Text = "Cuarta pregunta";

                        contador++;
                    }
                    break;

                case 5:
                    {
                        if (radioButton1.Checked == true || radioButton2.Checked == true || radioButton3.Checked == true)
                        {
                            if (radioButton1.Checked)
                            {
                                aciertos++;
                                listBox1.Items.Add("Respuesta correcta");
                            }
                            else
                            {
                                listBox1.Items.Add("Respuesta erronea");
                            }
                        }
                        else
                        {
                            listBox1.Items.Add("Pregunta no respondida");
                        }
                        contador++;
                        label1.Text = "Quinta pregunta";
                        radioButton1.Text = "NO SE QUE PREGUNTAS PONER";
                        button1.Text = "Finalizar test";
                      
                        
                    }
                    break;
                case 6:
                    {
                        if (radioButton1.Checked == true || radioButton2.Checked == true || radioButton3.Checked == true)
                        {
                            if (radioButton1.Checked)
                            {
                                aciertos++;
                                listBox1.Items.Add("Respuesta correcta");
                            }
                            else
                            {
                                listBox1.Items.Add("Respuesta erronea");
                            }
                        }
                        else
                        {
                            listBox1.Items.Add("Pregunta no respondida");
                        }
                        contador++;
                        label1.Text = "Has acertado " + aciertos.ToString();
                        listBox1.Visible = true;
                        listBox1.Text = "Respuestas: ";
                        radioButton1.Visible = false;
                        radioButton2.Visible = false;
                        radioButton3.Visible = false;
                        button1.Text = "Cerrar formulario";

                    }
                    break;
                default:
                    {
                        Close();
                    }break;
            }
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            radioButton3.Checked = false;


        }

    }
}
