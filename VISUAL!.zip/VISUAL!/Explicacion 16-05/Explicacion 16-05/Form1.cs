﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Explicacion_16_05
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Como añadir columnas al ListViews
            //listView1.Columns.Add("Diesel");

            //como meter datos en un listViews
            ListViewItem lvi = new ListViewItem("7468CKL");
            lvi.SubItems.Add("Fiat 500");
            lvi.SubItems.Add("Blanco");
            lvi.SubItems.Add("1546422");
            listView1.Items.Add(lvi);

            //Otra forma
            string[] datos = { "8739PQF", "Opel Corsa", "Negro", "546504" };
            ListViewItem lvi2 = new ListViewItem(datos);
            listView1.Items.Add(lvi2);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Si hay algo seleccionado
            if (listView1.SelectedIndices.Count > 0)
            {
                //solo borra uno, pero puedes seleccionar mas de uno, para evitar esto se pone multiselec 'false'
                int pos = listView1.SelectedIndices[0]; 
                listView1.Items.RemoveAt(pos);
                //GRIDLINE SE VE LAS RAYAS DE LA TABLA
                //FULLROWSELECT SE MARCA COMPLETAMENTE
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedIndices.Count > 0)
            {
                int pos = listView1.SelectedIndices[0];
                //He creado un list view con todos los elementos de la fila seleccionada
                ListViewItem lvi = listView1.Items[pos];
                string kms = lvi.SubItems[3].Text;
                int kmsi = int.Parse(kms);
                kmsi = kmsi + 100;
                lvi.SubItems[3].Text = kmsi.ToString();

            }
        }

    }
}
