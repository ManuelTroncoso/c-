﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Segundo_Ejercicio
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Nuevo_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }

        private void Guardar_Click(object sender, EventArgs e)
        {
            StreamWriter sr = new StreamWriter("bloc.txt");
            sr.WriteLine(textBox1.Text);
            sr.Close();
        }

        private void Abrir_Click(object sender, EventArgs e)
        {
            StreamReader sr = new StreamReader("bloc.txt");
            string a = "";
            while (!sr.EndOfStream)
            {
                a =  a + sr.ReadLine() + "\r\n";
            }
            textBox1.Text = a;
            sr.Close();
        }
    }
}
