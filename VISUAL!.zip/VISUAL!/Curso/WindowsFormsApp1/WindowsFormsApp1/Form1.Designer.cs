﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelPelota = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.ButtonArriba = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.buttonIzquierda = new System.Windows.Forms.Button();
            this.buttonCentro = new System.Windows.Forms.Button();
            this.buttonDerecha = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.buttonAbajo = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // labelPelota
            // 
            this.labelPelota.AutoSize = true;
            this.labelPelota.Location = new System.Drawing.Point(458, 147);
            this.labelPelota.Name = "labelPelota";
            this.labelPelota.Size = new System.Drawing.Size(15, 13);
            this.labelPelota.TabIndex = 0;
            this.labelPelota.Text = "O";
            this.labelPelota.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(360, 338);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "Diagonal Izq";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // ButtonArriba
            // 
            this.ButtonArriba.Location = new System.Drawing.Point(441, 338);
            this.ButtonArriba.Name = "ButtonArriba";
            this.ButtonArriba.Size = new System.Drawing.Size(75, 23);
            this.ButtonArriba.TabIndex = 2;
            this.ButtonArriba.Text = "Arriba";
            this.ButtonArriba.UseVisualStyleBackColor = true;
            this.ButtonArriba.Click += new System.EventHandler(this.ButtonArriba_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(522, 338);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 3;
            this.button3.Text = "button3";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // buttonIzquierda
            // 
            this.buttonIzquierda.Location = new System.Drawing.Point(360, 367);
            this.buttonIzquierda.Name = "buttonIzquierda";
            this.buttonIzquierda.Size = new System.Drawing.Size(75, 23);
            this.buttonIzquierda.TabIndex = 4;
            this.buttonIzquierda.Text = "Izquierda";
            this.buttonIzquierda.UseVisualStyleBackColor = true;
            this.buttonIzquierda.Click += new System.EventHandler(this.buttonIzquierda_Click);
            // 
            // buttonCentro
            // 
            this.buttonCentro.Location = new System.Drawing.Point(441, 367);
            this.buttonCentro.Name = "buttonCentro";
            this.buttonCentro.Size = new System.Drawing.Size(75, 23);
            this.buttonCentro.TabIndex = 5;
            this.buttonCentro.Text = "Centrar";
            this.buttonCentro.UseVisualStyleBackColor = true;
            this.buttonCentro.Click += new System.EventHandler(this.buttonCentro_Click);
            // 
            // buttonDerecha
            // 
            this.buttonDerecha.Location = new System.Drawing.Point(522, 367);
            this.buttonDerecha.Name = "buttonDerecha";
            this.buttonDerecha.Size = new System.Drawing.Size(75, 23);
            this.buttonDerecha.TabIndex = 6;
            this.buttonDerecha.Text = "Derecha";
            this.buttonDerecha.UseVisualStyleBackColor = true;
            this.buttonDerecha.Click += new System.EventHandler(this.buttonDerecha_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(360, 396);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 23);
            this.button7.TabIndex = 7;
            this.button7.Text = "button7";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // buttonAbajo
            // 
            this.buttonAbajo.Location = new System.Drawing.Point(441, 396);
            this.buttonAbajo.Name = "buttonAbajo";
            this.buttonAbajo.Size = new System.Drawing.Size(75, 23);
            this.buttonAbajo.TabIndex = 8;
            this.buttonAbajo.Text = "Abajo";
            this.buttonAbajo.UseVisualStyleBackColor = true;
            this.buttonAbajo.Click += new System.EventHandler(this.buttonAbajo_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(522, 396);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(75, 23);
            this.button9.TabIndex = 9;
            this.button9.Text = "button9";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.labelPelota);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(932, 308);
            this.panel1.TabIndex = 10;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(956, 431);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.buttonAbajo);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.buttonDerecha);
            this.Controls.Add(this.buttonCentro);
            this.Controls.Add(this.buttonIzquierda);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.ButtonArriba);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label labelPelota;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button ButtonArriba;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button buttonIzquierda;
        private System.Windows.Forms.Button buttonCentro;
        private System.Windows.Forms.Button buttonDerecha;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button buttonAbajo;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Panel panel1;
    }
}

