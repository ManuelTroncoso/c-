﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {

        //Constructores
        int y;
        int x;

        public Form1()
        {
            InitializeComponent();
            x = labelPelota.Location.X;
            y = labelPelota.Location.Y;
        }

        private void ButtonArriba_Click(object sender, EventArgs e)
        {
            labelPelota.Location = new Point(labelPelota.Location.X, labelPelota.Location.Y - 10);

        }

        private void buttonCentro_Click(object sender, EventArgs e)
        {
            labelPelota.Location = new Point(x, y);
        }

        private void buttonAbajo_Click(object sender, EventArgs e)
        {
            labelPelota.Location = new Point(labelPelota.Location.X, labelPelota.Location.Y + 10);
        }

        private void buttonDerecha_Click(object sender, EventArgs e)
        {
            labelPelota.Location = new Point(labelPelota.Location.X + 10, labelPelota.Location.Y);
        }

        private void buttonIzquierda_Click(object sender, EventArgs e)
        {
            labelPelota.Location = new Point(labelPelota.Location.X - 10, labelPelota.Location.Y);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            labelPelota.Location = new Point(labelPelota.Location.X - 10, labelPelota.Location.Y - 5);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            labelPelota.Location = new Point(labelPelota.Location.X + 10, labelPelota.Location.Y - 5);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            labelPelota.Location = new Point(labelPelota.Location.X + 10, labelPelota.Location.Y + 5);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            labelPelota.Location = new Point(labelPelota.Location.X - 10, labelPelota.Location.Y + 5);
        }
    }
}
