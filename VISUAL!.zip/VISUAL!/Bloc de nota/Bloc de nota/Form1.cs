﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bloc_de_nota
{
    public partial class form1 : Form
    {
        //Atributo
        string nombre = "";
        bool cambios = false;
        public form1()
        {
            InitializeComponent();
        }

        private void nuevoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (cambios == true && textBox.Text != "")
            {
                DialogResult dr = MessageBox.Show("¿Desea guardar los cambios del fichero?", "",
                MessageBoxButtons.YesNo, MessageBoxIcon.None);
                if (dr == DialogResult.Yes)
                {
                    if (File.Exists(nombre))
                    {

                        StreamWriter sw = new StreamWriter(nombre);
                        sw.WriteLine(textBox.Text);
                        sw.Close();
                        textBox.Text = "";
                        cambios = false;
                    }
                    else
                    {
                        DialogResult dr3;
                        dr3 = saveFileDialog1.ShowDialog();
                        if (dr3 == DialogResult.OK)
                        {
                            string fichero = saveFileDialog1.FileName;
                            saveFileDialog1.DefaultExt = "txt";
                            StreamWriter sw = new StreamWriter(fichero + ".txt");
                            sw.WriteLine(textBox.Text);
                            sw.Close();
                            textBox.Text = "";
                            cambios = false;
                        }
                    }

                }
                else
                {
                    textBox.Text = "";
                }
            }
            else
            {
                textBox.Text = "";
            }
        }

        private void abrirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult dr;
            dr = openFileDialog1.ShowDialog();
            //Esto es para que nos muestre un cuadro de dialogo como este:
            //Pero esto no hace nada a no ser que nosotros le indiquemos lo que tiene que hacer 
            //Aqui abajo se indica lo que tiene que hacer

            if (dr == DialogResult.OK)
            {
                string fichero = openFileDialog1.FileName;
                string texto = "";
                StreamReader sr = new StreamReader(fichero);
                while (!sr.EndOfStream)
                {
                    texto = texto + sr.ReadLine() + "\r\n";
                }
                textBox.Text = texto;
                sr.Close();
                nombre = fichero;
                cambios = false;
            }
            this.Text = Path.GetFileName(nombre) + ": Bloc de notas";
        }

        private void guardarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (File.Exists(nombre) && nombre != "")
            {
                StreamWriter sw = new StreamWriter(nombre);
                sw.WriteLine(textBox.Text);
                sw.Close();
            }
            else
            {
                DialogResult dr;
                dr = saveFileDialog1.ShowDialog();
                if (dr == DialogResult.OK)
                {
                    string fichero = saveFileDialog1.FileName;
                    saveFileDialog1.DefaultExt = "txt";
                    StreamWriter sw = new StreamWriter(fichero + ".txt");
                    sw.WriteLine(textBox.Text);
                    sw.Close();

                }
            }
            cambios = false;
        }

        private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void guardarComoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult dr;
            dr = saveFileDialog1.ShowDialog();
            //Esto es igual que el de arriba nos abre un menú como el de abrir
            if (dr == DialogResult.OK)//Las cosas que hay en azul son las opciones posible, en este caso nuestro cuadro tiene OK, cancel 
            {
                string fichero = saveFileDialog1.FileName;
                saveFileDialog1.DefaultExt = "txt";
                StreamWriter sw = new StreamWriter(fichero + ".txt");
                sw.WriteLine(textBox.Text);
                sw.Close();
                cambios = false;
            }
        }

        private void salirToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            DialogResult dr2 = MessageBox.Show("Salir", "¿Está seguro de que quiere salir?", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (dr2 == DialogResult.Yes)
            {
                if (cambios == true)
                {

                    DialogResult dr = MessageBox.Show("¿Desea guardar los cambios del fichero?", "",
                        MessageBoxButtons.YesNo, MessageBoxIcon.None);
                    if (dr == DialogResult.Yes)
                    {
                        if (File.Exists(nombre))
                        {

                            StreamWriter sw = new StreamWriter(nombre);
                            sw.WriteLine(textBox.Text);
                            sw.Close();
                            Close();
                        }
                        else
                        {
                            DialogResult dr3;
                            dr3 = saveFileDialog1.ShowDialog();
                            if (dr3 == DialogResult.OK)
                            {
                                string fichero = saveFileDialog1.FileName;
                                saveFileDialog1.DefaultExt = "txt";
                                StreamWriter sw = new StreamWriter(fichero + ".txt");
                                sw.WriteLine(textBox.Text);
                                sw.Close();
                                cambios = false;
                            }
                        }

                    }
                    else
                    {
                        Close();
                    }
                }
                else
                {
                    Close();
                }
            }


            //Que me pregunte para salir.
        }

        private void textBox_TextChanged(object sender, EventArgs e)
        {
            cambios = true;

        }

        private void textBox_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void deshacerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox.Undo();
        }

        private void cortarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox.Cut();
        }

        private void copiarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox.Copy();
        }

        private void pegarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox.Paste();
        }

        private void eliminarToolStripMenuItem_Click(object sender, EventArgs e)
        {

            textBox.SelectedText = "";
        }

        private void selecionarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox.SelectAll();
        }

        private void ediciónToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (textBox.SelectedText != "")
            {
                eliminarToolStripMenuItem.Enabled = true;
            }
            else
            {
                eliminarToolStripMenuItem.Enabled = false;
            }
        }

        private void horaYFechaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox.Text = DateTime.Today.ToString();
        }

        private void ajusteDeLineaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (ajusteDeLineaToolStripMenuItem.Checked)
            {
                textBox.WordWrap = true;
            }
            else
            {
                textBox.WordWrap = false;
            }
        }

        private void fuenteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fontDialog1.ShowDialog();
            textBox.Font = fontDialog1.Font;
        }

        private void form1_TextChanged(object sender, EventArgs e)
        {
        }

        private void form1_Load(object sender, EventArgs e)
        {
            if (nombre == "")
            {
                this.Text = "Sin titulo: Bloc de notas";
            }
            else
            {
                this.Text = nombre + ": Bloc de notas";
            }
        }

        private void form1_FormClosed(object sender, FormClosedEventArgs e)
        {

        }
    }
}
