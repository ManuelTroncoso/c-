﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Séptimo_Ejercicio
{
    public partial class Form1 : Form
    {
        //Atributos 
        DateTime fecha;
        string diaActual = DateTime.Today.ToString("dd");
        //Constructor

        public Form1()
        {
            InitializeComponent();
            fecha = DateTime.Today;

            textBoxdias.Text = fecha.ToString("dd");
            textBoxmeses.Text = fecha.ToString("MM");
            textBoxanno.Text = fecha.ToString("yyyy");

        }
        private void textBox3_TextChanged(object sender, EventArgs e)
        {
        }

        private void buttonmas_Click(object sender, EventArgs e)
        {
            string a = textBoxdias.Text + textBoxmeses.Text + textBoxanno.Text;
            StreamWriter sw = new StreamWriter(a + ".txt");
            sw.Write(textBox1.Text);
            sw.Close();

            //Habrá que ponerle un maximo y un minimo con un if.

            fecha = fecha.AddDays(1);

            textBoxdias.Text = fecha.ToString("dd");
            textBoxmeses.Text = fecha.ToString("MM");
            textBoxanno.Text = fecha.ToString("yyyy");

            a = textBoxdias.Text + textBoxmeses.Text + textBoxanno.Text;
            if (File.Exists(a + ".txt"))
            {
                StreamReader sr = new StreamReader(a + ".txt");
                textBox1.Text = sr.ReadToEnd();
                sr.Close();
            }
            else
            {
                textBox1.Text = "";
            }

        }

        private void Buttonmenos_Click(object sender, EventArgs e)
        {

            string a = textBoxdias.Text + textBoxmeses.Text + textBoxanno.Text;
            StreamWriter sw = new StreamWriter(a + ".txt");
            sw.Write(textBox1.Text);
            sw.Close();

            //Habrá que ponerle un maximo y un minimo con un if.

            fecha = fecha.AddDays(-1);

            textBoxdias.Text = fecha.ToString("dd");
            textBoxmeses.Text = fecha.ToString("MM");
            textBoxanno.Text = fecha.ToString("yyyy");

            a = textBoxdias.Text + textBoxmeses.Text + textBoxanno.Text;
            if (File.Exists(a + ".txt"))
            {
                StreamReader sr = new StreamReader(a + ".txt");
                textBox1.Text = sr.ReadToEnd();
                sr.Close();
            }
            else
            {
                textBox1.Text = "";
            }

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            string a = textBoxdias.Text + textBoxmeses.Text + textBoxanno.Text;
            StreamWriter sw = new StreamWriter(a + ".txt");
            sw.Write(textBox1.Text);
            sw.Close();
        }
    }
}
