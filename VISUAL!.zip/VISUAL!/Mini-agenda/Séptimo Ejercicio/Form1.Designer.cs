﻿namespace Séptimo_Ejercicio
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBoxmeses = new System.Windows.Forms.TextBox();
            this.textBoxdias = new System.Windows.Forms.TextBox();
            this.textBoxanno = new System.Windows.Forms.TextBox();
            this.buttonmas = new System.Windows.Forms.Button();
            this.Buttonmenos = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(14, 9);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(260, 161);
            this.textBox1.TabIndex = 0;
            // 
            // textBoxmeses
            // 
            this.textBoxmeses.Location = new System.Drawing.Point(106, 176);
            this.textBoxmeses.Name = "textBoxmeses";
            this.textBoxmeses.Size = new System.Drawing.Size(73, 20);
            this.textBoxmeses.TabIndex = 3;
            this.textBoxmeses.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // textBoxdias
            // 
            this.textBoxdias.Location = new System.Drawing.Point(14, 176);
            this.textBoxdias.Name = "textBoxdias";
            this.textBoxdias.Size = new System.Drawing.Size(75, 20);
            this.textBoxdias.TabIndex = 4;
            this.textBoxdias.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // textBoxanno
            // 
            this.textBoxanno.Location = new System.Drawing.Point(199, 176);
            this.textBoxanno.Name = "textBoxanno";
            this.textBoxanno.Size = new System.Drawing.Size(75, 20);
            this.textBoxanno.TabIndex = 5;
            this.textBoxanno.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // buttonmas
            // 
            this.buttonmas.Location = new System.Drawing.Point(14, 200);
            this.buttonmas.Name = "buttonmas";
            this.buttonmas.Size = new System.Drawing.Size(34, 20);
            this.buttonmas.TabIndex = 6;
            this.buttonmas.Text = "+";
            this.buttonmas.UseVisualStyleBackColor = true;
            this.buttonmas.Click += new System.EventHandler(this.buttonmas_Click);
            // 
            // Buttonmenos
            // 
            this.Buttonmenos.Location = new System.Drawing.Point(55, 200);
            this.Buttonmenos.Name = "Buttonmenos";
            this.Buttonmenos.Size = new System.Drawing.Size(34, 20);
            this.Buttonmenos.TabIndex = 7;
            this.Buttonmenos.Text = "-";
            this.Buttonmenos.UseVisualStyleBackColor = true;
            this.Buttonmenos.Click += new System.EventHandler(this.Buttonmenos_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.Buttonmenos);
            this.Controls.Add(this.buttonmas);
            this.Controls.Add(this.textBoxanno);
            this.Controls.Add(this.textBoxdias);
            this.Controls.Add(this.textBoxmeses);
            this.Controls.Add(this.textBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBoxmeses;
        private System.Windows.Forms.TextBox textBoxdias;
        private System.Windows.Forms.TextBox textBoxanno;
        private System.Windows.Forms.Button buttonmas;
        private System.Windows.Forms.Button Buttonmenos;
    }
}

