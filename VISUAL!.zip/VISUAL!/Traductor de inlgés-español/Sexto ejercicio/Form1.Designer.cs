﻿namespace Sexto_ejercicio
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.TBEspanol = new System.Windows.Forms.TextBox();
            this.TBInglés = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.BottonAIngles = new System.Windows.Forms.Button();
            this.BottonAEspañol = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // TBEspanol
            // 
            this.TBEspanol.Location = new System.Drawing.Point(28, 70);
            this.TBEspanol.Name = "TBEspanol";
            this.TBEspanol.Size = new System.Drawing.Size(201, 20);
            this.TBEspanol.TabIndex = 0;
            // 
            // TBInglés
            // 
            this.TBInglés.Location = new System.Drawing.Point(28, 172);
            this.TBInglés.Name = "TBInglés";
            this.TBInglés.Size = new System.Drawing.Size(201, 20);
            this.TBInglés.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Español";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 156);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Inglés";
            // 
            // BottonAIngles
            // 
            this.BottonAIngles.Location = new System.Drawing.Point(232, 69);
            this.BottonAIngles.Name = "BottonAIngles";
            this.BottonAIngles.Size = new System.Drawing.Size(35, 20);
            this.BottonAIngles.TabIndex = 4;
            this.BottonAIngles.Text = "T";
            this.BottonAIngles.UseVisualStyleBackColor = true;
            this.BottonAIngles.Click += new System.EventHandler(this.BottonAIngles_Click);
            // 
            // BottonAEspañol
            // 
            this.BottonAEspañol.Location = new System.Drawing.Point(232, 172);
            this.BottonAEspañol.Name = "BottonAEspañol";
            this.BottonAEspañol.Size = new System.Drawing.Size(35, 20);
            this.BottonAEspañol.TabIndex = 5;
            this.BottonAEspañol.Text = "T";
            this.BottonAEspañol.UseVisualStyleBackColor = true;
            this.BottonAEspañol.Click += new System.EventHandler(this.BottonAEspañol_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.BottonAEspañol);
            this.Controls.Add(this.BottonAIngles);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TBInglés);
            this.Controls.Add(this.TBEspanol);
            this.Name = "Form1";
            this.Text = "Traductor de Inglés-Español";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TBEspanol;
        private System.Windows.Forms.TextBox TBInglés;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button BottonAIngles;
        private System.Windows.Forms.Button BottonAEspañol;
    }
}

