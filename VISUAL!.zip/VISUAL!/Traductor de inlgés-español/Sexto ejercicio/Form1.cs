﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sexto_ejercicio
{
    public partial class Form1 : Form
    {
        //atributos
        List<string> spain;
        List<string> english;
        /// <summary>
        /// Te consigue todas las palabras en espannol
        /// </summary>
        /// <returns></returns>
        private void LeeFichero ()
        {
            StreamReader sr = new StreamReader("Traduccion.txt");
            string a;
            string[] a2;
            spain = new List<string>();
            english = new List<string>();
            while (!sr.EndOfStream)
            {
                a = sr.ReadLine();
                a2 = a.Split(',');
                spain.Add(a2[0]);
                english.Add(a2[1].TrimStart(' '));
            }
        }
        public Form1()
        {
            InitializeComponent();
           
        }

        private void BottonAIngles_Click(object sender, EventArgs e)
        {
            LeeFichero();
            int i;
            //spain = new List<string>();
            for (i = 0; i < spain.Count; i++)
            {
                if (TBEspanol.Text == spain[i])
                {
                    TBInglés.Text = english[i];
                }
            }
            if(TBInglés.Text == "")
            {
                MessageBox.Show("Esta palabra no existe");
            }
        }

        private void BottonAEspañol_Click(object sender, EventArgs e)
        {
            LeeFichero();
            int i;
            //spain = new List<string>();
            for (i = 0; i < spain.Count; i++)
            {
                if (TBInglés.Text == english[i])
                {
                    TBEspanol.Text = spain[i];
                }
            }
            if (TBEspanol.Text == "")
            {
                MessageBox.Show("Esta palabra no existe");
            }
        }
    }
}
