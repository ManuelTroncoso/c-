﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tercer_Ejercicio
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            double operador1, operador2, solucion;
            bool uno = double.TryParse(TBoperador1.Text, out operador1);
            bool dos = double.TryParse(TBoperador2.Text, out operador2);
            solucion = operador1 + operador2;
            if (uno == false)
            {
                MessageBox.Show("El numero no es válido");
            }
            else
            {
                TBresultado.Text = Convert.ToString(solucion);
                label1.Text = "+";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double operador1, operador2, solucion;
            bool uno = double.TryParse(TBoperador1.Text, out operador1);
            bool dos = double.TryParse(TBoperador2.Text, out operador2);
           solucion =  operador1 / operador2;
            if (uno == false)
            {
                MessageBox.Show("El numero no es válido");
            }
            else
            {
                TBresultado.Text = Convert.ToString(solucion);
                label1.Text = "/";
            }

        }

        private void BTresta_Click(object sender, EventArgs e)
        {

            double operador1, operador2, solucion;
            bool uno = double.TryParse(TBoperador1.Text, out operador1);
            bool dos = double.TryParse(TBoperador2.Text, out operador2);
            solucion = operador1 - operador2;
            if (uno == false)
            {
                MessageBox.Show("El numero no es válido");
            }
            else
            {
                TBresultado.Text = Convert.ToString(solucion);
                label1.Text = "-";
            }
        }

        private void BTmultiplicacion_Click(object sender, EventArgs e)
        {

            double operador1, operador2, solucion;
            bool uno = double.TryParse(TBoperador1.Text, out operador1);
            bool dos = double.TryParse(TBoperador2.Text, out operador2);
            solucion = operador1 * operador2;
            if (uno == false)
            {
                MessageBox.Show("El numero no es válido");
            }
            else
            {
                TBresultado.Text = Convert.ToString(solucion);
                label1.Text = "x";
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
