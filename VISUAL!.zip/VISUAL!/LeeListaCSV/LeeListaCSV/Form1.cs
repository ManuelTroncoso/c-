﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LeeListaCSV
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        /// <summary>
        /// Crea las columnas 
        /// </summary>
        /// <param name="nombre">nombre del fichero</param>
        private void Crea_columnas(string nombre)
        {
            StreamReader sr = new StreamReader(nombre);
            string columnas = sr.ReadLine();
            string[] columna = columnas.Split(';');
            for (int i = 0; i < columna.Length; i++)
            { 
                listView1.Columns.Add(columna[i]);
            }
            sr.Close();
        }
        /// <summary>
        /// Devuelve 'true' si el archivo existe
        /// </summary>
        /// <param name="nombre">nombre del archivo</param>
        /// <returns></returns>
        private bool Buscafichero(string nombre)
        {
            return File.Exists(nombre);
        }
        /// <summary>
        /// Lee un fichero y lo muestra en el listview
        /// </summary>
        /// <param name="nombre">nombre del fichero</param>
        private void Lee_fichero (string nombre)
        {
            StreamReader sr = new StreamReader(nombre);
            sr.ReadLine();
            
            while (!sr.EndOfStream)
            {
                string filas = sr.ReadLine();
                string[] fila = filas.Split(';');
                ListViewItem lvi2 = new ListViewItem(fila);
                listView1.Items.Add(lvi2);
            }
           
            sr.Close();
        }

        private void buttonBuscar_Click(object sender, EventArgs e)
        {
            if(Buscafichero(textBox1.Text) == true)
            {
                Crea_columnas(textBox1.Text);
                Lee_fichero(textBox1.Text);
            }
            else
            {
                MessageBox.Show("No se encuentra el fichero con ese nombre");
            }
        }
    }
}
