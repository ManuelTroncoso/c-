﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Validar = new System.Windows.Forms.Button();
            this.Solucion = new System.Windows.Forms.Label();
            this.Numero = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Otro_grupo = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Validar
            // 
            this.Validar.BackColor = System.Drawing.Color.Transparent;
            this.Validar.Enabled = false;
            this.Validar.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Validar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.Validar.Location = new System.Drawing.Point(684, 370);
            this.Validar.Name = "Validar";
            this.Validar.Size = new System.Drawing.Size(176, 57);
            this.Validar.TabIndex = 0;
            this.Validar.Text = "COMPROBAR";
            this.Validar.UseVisualStyleBackColor = false;
            this.Validar.DockChanged += new System.EventHandler(this.Validar_Click);
            this.Validar.Click += new System.EventHandler(this.Validar_Click);
            // 
            // Solucion
            // 
            this.Solucion.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.Solucion.BackColor = System.Drawing.Color.Transparent;
            this.Solucion.Font = new System.Drawing.Font("Consolas", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Solucion.ForeColor = System.Drawing.Color.Linen;
            this.Solucion.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.Solucion.Location = new System.Drawing.Point(230, 139);
            this.Solucion.Name = "Solucion";
            this.Solucion.Size = new System.Drawing.Size(823, 125);
            this.Solucion.TabIndex = 1;
            this.Solucion.Text = "label1";
            this.Solucion.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Solucion.Visible = false;
            // 
            // Numero
            // 
            this.Numero.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Numero.ForeColor = System.Drawing.Color.Lime;
            this.Numero.Location = new System.Drawing.Point(497, 325);
            this.Numero.Name = "Numero";
            this.Numero.PasswordChar = '*';
            this.Numero.Size = new System.Drawing.Size(363, 39);
            this.Numero.TabIndex = 2;
            this.Numero.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Numero.TextChanged += new System.EventHandler(this.Numero_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(494, 309);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(280, 15);
            this.label1.TabIndex = 3;
            this.label1.Text = "Introduce aquí el código para comprobarlo";
            // 
            // Otro_grupo
            // 
            this.Otro_grupo.BackColor = System.Drawing.Color.Transparent;
            this.Otro_grupo.Enabled = false;
            this.Otro_grupo.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Otro_grupo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.Otro_grupo.Location = new System.Drawing.Point(497, 370);
            this.Otro_grupo.Name = "Otro_grupo";
            this.Otro_grupo.Size = new System.Drawing.Size(181, 56);
            this.Otro_grupo.TabIndex = 4;
            this.Otro_grupo.Text = "OTRO NÚMERO";
            this.Otro_grupo.UseVisualStyleBackColor = false;
            this.Otro_grupo.Click += new System.EventHandler(this.Otro_grupo_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1174, 678);
            this.Controls.Add(this.Otro_grupo);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Numero);
            this.Controls.Add(this.Solucion);
            this.Controls.Add(this.Validar);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "u";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Validar;
        private System.Windows.Forms.Label Solucion;
        private System.Windows.Forms.TextBox Numero;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Otro_grupo;
    }
}

