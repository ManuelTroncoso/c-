﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Validar_Click(object sender, EventArgs e)
        {
            int i = 0;
          

         
                string[] numero = { "7892", "6620", "3433", "5411", "1698", "9090" };
                string[] palabra = { "1. Enciende la máquina: Presione el botón verde y espera a que la pantalla superior se ilumine", "2. Cuando escuche un pitido introduzca la fecha a la que quieres viajar",
                "3. Compruebe que toda las bombillas están correctamente iluminada y en color blanco", "4. Accione el compresor de viaje temporal y añada los polvos místicos por el tubo principal izquierdo.", "5. Eleve las palancas pequeñas situadas junto a los botones, hasta el grado necesario de temperatura, según la fugacidad indicada en el paquete de los polvos.",
                    "6. Tire con fuerza de la palanca grande y disfrute de un viaje mágico de la mano de la TimeTravel National Agency." };
                Console.WriteLine("Introduce tu código:");
                string numero_introducido = Console.ReadLine();
                SoundPlayer simpleSound = new SoundPlayer("Acierto.wav");
                SoundPlayer error = new SoundPlayer("ERROR.wav");
                for (i = 0; i < numero.Length; i++)
                {
                    if (numero[i] == Numero.Text)
                    {

                        simpleSound.Play();
                        Solucion.Visible = true;
                        Solucion.Text = (palabra[i]);
                        break;
                       
                    }
                    if (numero[i] != Numero.Text && i == numero.Length - 1)
                    {
                        error.Play();
                        Solucion.Visible = true;
                        Solucion.Text = ("Números erroneos, pulsa 'intro' y vuelve a introducir los números");
                    }


                }

        }

        private void Otro_grupo_Click(object sender, EventArgs e)
        {
            Solucion.Visible = false;
            Solucion.Text = "";
            Numero.Text = "";
        }

        private void Numero_TextChanged(object sender, EventArgs e)
        {
            if (Numero.Text != "")
            {
                Otro_grupo.Enabled = true;
                Validar.Enabled = true;
            }
            else
            {
                Validar.Enabled = false;
                Otro_grupo.Enabled = false;
            }
            
           
               
        }
    }
}
