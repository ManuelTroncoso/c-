﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GeneradorTitulosPelículas
{
    public partial class Form1 : Form
    {
        Random r = new Random();
        public Form1()
        {
            InitializeComponent();
            annade_a_Lista();
            Buttom.Enabled = false;
        }
        /// <summary>
        /// Añade a la lista un titulo
        /// </summary>
        private void annade_a_Lista()
        {
            StreamReader sr1 = new StreamReader("Primera parte del titulo.txt");
            StreamReader sr2 = new StreamReader("Segunda parte del titulo.txt");
            while (!sr1.EndOfStream)
            {
                comboBoxPrimera.Items.Add(sr1.ReadLine());
            }
            while (!sr2.EndOfStream)
            {
                comboBoxSegunda.Items.Add(sr2.ReadLine());
            }
        }

        private void Buttom_Click(object sender, EventArgs e)
        {
            label1.Visible = true;
            label1.Text = comboBoxPrimera.Text + " " + comboBoxSegunda.Text;
            label1.Font = new Font(Font.FontFamily.Name, 15);
            label1.ForeColor = Color.Lime;
        }

        private void ButtomAleatorio_Click(object sender, EventArgs e)
        {
            label1.Visible = true;
            int aleatorio = r.Next(0, comboBoxPrimera.Items.Count);
            int aleatorio2 = r.Next(0, comboBoxSegunda.Items.Count);
            label1.Text = comboBoxPrimera.Items[aleatorio] + " " + comboBoxSegunda.Items[aleatorio2];
            label1.Font = new Font(Font.FontFamily.Name, 15);
            label1.ForeColor = Color.Lime;
        }

        private void comboBoxPrimera_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxPrimera.Text != "" && comboBoxSegunda.Text != "")
            {
                Buttom.Enabled = true;
            }
            else
            {
                Buttom.Enabled = false;
            }
        }

        private void comboBoxSegunda_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxPrimera.Text != "" && comboBoxSegunda.Text != "")
            {
                Buttom.Enabled = true;
            }
            else
            {
                Buttom.Enabled = false;
            }
        }
    }
}
