﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GeneradorDados
{
    public partial class Form1 : Form
    {
        Random r = new Random();
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonTirar_Click(object sender, EventArgs e)
        {
            int ncaras = 0;
            int ntiradas = 0;
            int aleatorio, suma;
                ncaras = (int)numericUpDownDados.Value + 1;
                ntiradas = (int)numericUpDownTirada.Value;
                suma = 0;
                for (int i = 0; i < ntiradas; i++)
                {
                    aleatorio = r.Next(1, ncaras);
                    listBox1.Items.Add(aleatorio);
                    suma = suma + aleatorio;
                }
                textBox1.Text = suma.ToString();
        }

    }
}
