﻿namespace GeneradorDados
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.numericUpDownTirada = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownDados = new System.Windows.Forms.NumericUpDown();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.buttonTirar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownTirada)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownDados)).BeginInit();
            this.SuspendLayout();
            // 
            // numericUpDownTirada
            // 
            this.numericUpDownTirada.Location = new System.Drawing.Point(15, 18);
            this.numericUpDownTirada.Name = "numericUpDownTirada";
            this.numericUpDownTirada.Size = new System.Drawing.Size(120, 20);
            this.numericUpDownTirada.TabIndex = 0;
            // 
            // numericUpDownDados
            // 
            this.numericUpDownDados.Location = new System.Drawing.Point(152, 18);
            this.numericUpDownDados.Name = "numericUpDownDados";
            this.numericUpDownDados.Size = new System.Drawing.Size(120, 20);
            this.numericUpDownDados.TabIndex = 1;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(82, 83);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(120, 95);
            this.listBox1.TabIndex = 2;
            // 
            // buttonTirar
            // 
            this.buttonTirar.Location = new System.Drawing.Point(105, 184);
            this.buttonTirar.Name = "buttonTirar";
            this.buttonTirar.Size = new System.Drawing.Size(75, 23);
            this.buttonTirar.TabIndex = 3;
            this.buttonTirar.Text = "Tirar";
            this.buttonTirar.UseVisualStyleBackColor = true;
            this.buttonTirar.Click += new System.EventHandler(this.buttonTirar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Numero de tiradas";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(149, 2);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Numero de caras";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(208, 158);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(64, 20);
            this.textBox1.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonTirar);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.numericUpDownDados);
            this.Controls.Add(this.numericUpDownTirada);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownTirada)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownDados)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown numericUpDownTirada;
        private System.Windows.Forms.NumericUpDown numericUpDownDados;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button buttonTirar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
    }
}

