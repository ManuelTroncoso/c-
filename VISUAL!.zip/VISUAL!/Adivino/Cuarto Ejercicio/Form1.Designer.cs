﻿namespace Cuarto_Ejercicio
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Numero = new System.Windows.Forms.Label();
            this.Mayor = new System.Windows.Forms.Button();
            this.Acierto = new System.Windows.Forms.Button();
            this.Menor = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // Numero
            // 
            this.Numero.Location = new System.Drawing.Point(26, 93);
            this.Numero.Name = "Numero";
            this.Numero.Size = new System.Drawing.Size(233, 74);
            this.Numero.TabIndex = 0;
            this.Numero.Text = "Pulsa para comenzar";
            this.Numero.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Mayor
            // 
            this.Mayor.Location = new System.Drawing.Point(12, 226);
            this.Mayor.Name = "Mayor";
            this.Mayor.Size = new System.Drawing.Size(75, 23);
            this.Mayor.TabIndex = 1;
            this.Mayor.Text = "Mayor";
            this.Mayor.UseVisualStyleBackColor = true;
            this.Mayor.Click += new System.EventHandler(this.Mayor_Click);
            // 
            // Acierto
            // 
            this.Acierto.Location = new System.Drawing.Point(105, 226);
            this.Acierto.Name = "Acierto";
            this.Acierto.Size = new System.Drawing.Size(75, 23);
            this.Acierto.TabIndex = 2;
            this.Acierto.Text = "Acierto";
            this.Acierto.UseVisualStyleBackColor = true;
            this.Acierto.Click += new System.EventHandler(this.Acierto_Click);
            // 
            // Menor
            // 
            this.Menor.Location = new System.Drawing.Point(197, 226);
            this.Menor.Name = "Menor";
            this.Menor.Size = new System.Drawing.Size(75, 23);
            this.Menor.TabIndex = 3;
            this.Menor.Text = "Menor";
            this.Menor.UseVisualStyleBackColor = true;
            this.Menor.Click += new System.EventHandler(this.Menor_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 2000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.Menor);
            this.Controls.Add(this.Acierto);
            this.Controls.Add(this.Mayor);
            this.Controls.Add(this.Numero);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label Numero;
        private System.Windows.Forms.Button Mayor;
        private System.Windows.Forms.Button Acierto;
        private System.Windows.Forms.Button Menor;
        private System.Windows.Forms.Timer timer1;
    }
}

