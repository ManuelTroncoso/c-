﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cuarto_Ejercicio
{
    public partial class Form1 : Form
    {
        //Atributos 
        private int minimo = 1;
        private int maximo = 101;
        private Random aleatorio;
        private int numero;


        public Form1()
        {
            InitializeComponent();
            
            aleatorio = new Random();
            numero = aleatorio.Next(1, 101);
            Numero.Text = numero.ToString();
        }

        private void Mayor_Click(object sender, EventArgs e)
        {
            minimo = int.Parse(Numero.Text);
            int numero = aleatorio.Next(minimo, maximo);
            Numero.Text = numero.ToString();
        }

        private void Menor_Click(object sender, EventArgs e)
        {
            maximo = int.Parse(Numero.Text);
            int numero = aleatorio.Next(minimo, maximo);
            Numero.Text = numero.ToString();
        }
        private void Acierto_Click(object sender, EventArgs e)
        {
            Numero.Text = "SOY UN PUTO MÁQUINA ILLO!";
            //this.Update(); para actualizar el interfaz;
            timer1.Start();
            //Thread.Sleep(2000);
            //this.Close();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
