﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VisualGatos
{
    public partial class Form1 : Form
    {
        /// <summary>
        /// Crea las columnas
        /// </summary>
        private void Crea_columnas()
        {
           
            StreamReader sr = new StreamReader("Gatos.CSV");
            string columnas = sr.ReadLine();
            if (columnas != "Nombre;Color de ojos;Color de pelo;Peso;Raza;Tamaño")
            {
                sr.Close();
                StreamWriter sw = new StreamWriter("Gatos.CSV");
                sw.WriteLine("Nombre;Color de ojos;Color de pelo;Peso;Raza;Tamaño");
                sw.Close();
                StreamReader sr1 = new StreamReader("Gatos.CSV");
                string columnas1 = sr1.ReadLine();
                string[] columna = columnas1.Split(';');
                for (int i = 0; i < columna.Length; i++)
                {
                    listView1.Columns.Add(columna[i]);
                }
                sr1.Close();
            }
            else
            {
                string[] columna = columnas.Split(';');
                for (int i = 0; i < columna.Length; i++)
                {
                    listView1.Columns.Add(columna[i]);
                }
                sr.Close();

            }
            
        }
        /// <summary>
        /// crea filas
        /// </summary>
        private void CreaFilas()
        {
            StreamReader sr = new StreamReader("Gatos.CSV");
            sr.ReadLine();
            int i = 0;
            while (!sr.EndOfStream)
            {
                string filas = sr.ReadLine();
                if (filas != null)
                {
                    string[] fila = filas.Split(';');

                    listView1.Items.Add(fila[0]);
                    for (int j = 1; j < 6; j++)
                    {
                        listView1.Items[i].SubItems.Add(fila[j]);
                    }
                    i++;
                }
            }
            sr.Close();
        }
        /// <summary>
        /// Añade un gato a la lista
        /// </summary>
        private void AñadeALista()
        {
            string[] gatos = new string[6];
            gatos[0] = textBoxNombre.Text;
            gatos[1] = textBoxOColor.Text;
            gatos[2] = textBoxPColor.Text;
            gatos[3] = textBoxPeso.Text;
            gatos[4] = textBoxRaza.Text;
            gatos[5] = textBoxTamanho.Text;
            ListViewItem lvi2 = new ListViewItem(gatos);
            listView1.Items.Add(lvi2);

        }
        public Form1()
        {
            InitializeComponent();
            Crea_columnas();
            CreaFilas();
            
        }
        private void buttonNuevo_Click(object sender, EventArgs e)
        {
            textBoxNombre.Text = "";
            textBoxOColor.Text = "";
            textBoxPColor.Text = "";
            textBoxPeso.Text = "";
            textBoxRaza.Text = "";
            textBoxTamanho.Text = "";
        }
        
        private void buttonGuardar_Click(object sender, EventArgs e)
        {
            AñadeALista();
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        { 
            StreamWriter sw = new StreamWriter("Gatos.CSV");
            sw.WriteLine("Nombre;Color de ojos;Color de pelo;Peso;Raza;Tamaño");
            for (int i = 0; i < listView1.Items.Count; i++)
            {
                sw.Write(listView1.Items[i].SubItems[0].Text);
                for (int j = 1; j < listView1.Items[i].SubItems.Count; j++)
                {

                    sw.Write(";" + listView1.Items[i].SubItems[j].Text);

                }
                
                sw.WriteLine();
            }
            sw.Close();
            //Nombre;Color de ojos; Color de pelo;Peso;Raza;Tamaño

        }

        private void buttonBorrar_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedIndices.Count > 0)//mira si hay alguno señalado
            {
                int pos = listView1.SelectedIndices[0];//obitiene la posicion del señalado
                listView1.Items.RemoveAt(pos);
            }
        }

        private void buttonModificar_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedIndices.Count > 0)//mira si hay alguno señalado
            {
                int pos = listView1.SelectedIndices[0];//obitiene la posicion del señalado
                textBoxNombre.Text = listView1.Items[pos].Text;
                textBoxOColor.Text = listView1.Items[pos].SubItems[1].Text;
                textBoxPColor.Text = listView1.Items[pos].SubItems[2].Text; ;
                textBoxPeso.Text = listView1.Items[pos].SubItems[3].Text; ;
                textBoxRaza.Text = listView1.Items[pos].SubItems[4].Text; ;
                textBoxTamanho.Text = listView1.Items[pos].SubItems[5].Text;
                listView1.Items.RemoveAt(pos);
            }
            //Falta sustituirlo para guardarlo.
        }
    }
}
