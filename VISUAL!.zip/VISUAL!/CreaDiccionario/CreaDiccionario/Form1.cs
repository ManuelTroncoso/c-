﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CreaDiccionario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            if (File.Exists("ListBox.txt"))
            {
                StreamReader sr = new StreamReader("ListBox.txt");
                while (!sr.EndOfStream)
                {
                    listBox1.Items.Add(sr.ReadLine());
                }
                sr.Close();
            }
            else
            {
                MessageBox.Show("El fichero no existe, cree uno con el nombre \"ListBox.txt\"");
            }

        }
        /// <summary>
        /// Lee ficheros
        /// </summary>
        private void LeeFichero()
        {
            StreamReader sr = new StreamReader("ListBox.txt");
            while (!sr.EndOfStream)
            {
                listBox1.Items.Add(sr.ReadLine()); 
            }
            sr.Close();
        }
        private void buttonAnnadir_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "")
            {
                listBox1.Items.Add(textBox1.Text + "-" + textBox2.Text);
            }
           
        }

        private void buttonBorrar_Click(object sender, EventArgs e)
        {
            listBox1.Items.RemoveAt(listBox1.SelectedIndex);
            buttonBorrar.Enabled = false;

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1)
            {
                buttonBorrar.Enabled = true;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            StreamWriter sw = new StreamWriter("ListBox.txt");
            for (int i = 0; i < listBox1.Items.Count; i++)
            {
                sw.WriteLine(listBox1.Items[i]);
            }
            sw.Close();     
        }
    }
}
